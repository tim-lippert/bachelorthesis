#include <iostream>
#include <string>
#include <vector>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>
#include <chrono>
#include "einsum.h"

namespace py = pybind11;

py::tuple einsum(
    const std::vector<std::tuple<int, int, std::string>>& ssa_path,
    py::args tensors) {
    
    TimingsList all_timings; //Sammelt alle Zeitmessungen
    
    //Konvertiere Input-Tensoren in SparseTensor
    std::vector<SparseTensor> sparse_tensors;
    sparse_tensors.reserve(tensors.size() + ssa_path.size());
    for (auto& tensor_arg : tensors) {
        if (py::hasattr(tensor_arg, "is_sparse") && tensor_arg.attr("is_sparse").cast<bool>()) {
            SparseTensor st = torch_sparse_to_sparse_tensor(tensor_arg);
            sparse_tensors.push_back(st);
        } else {
            std::cout << "Kein Torch COO Tensor" << std::endl;
        }
    }
    
    //Iteration durch den Pfad
    for (size_t step = 0; step < ssa_path.size(); ++step) {
        const auto& [idx1, idx2, op_name] = ssa_path[step];
        
        if (idx1 >= sparse_tensors.size() || idx2 >= sparse_tensors.size()) {
            throw std::runtime_error("Invalid tensor indices in SSA path");
        }
        
        const SparseTensor& tensor1 = sparse_tensors[idx1];
        const SparseTensor& tensor2 = sparse_tensors[idx2];
        
        //Berechne die Kontraktion
        auto [result, step_timings] = perform_einsum(op_name, tensor1, tensor2);

        //Speichere Ergebnis und Timings
        sparse_tensors.push_back(result);
        all_timings.insert(all_timings.end(), step_timings.begin(), step_timings.end());
    }
    
    if (sparse_tensors.empty()) {
        return py::make_tuple(py::list(), py::none());
    }
    //std::cout << "(cpp) Ergebnistensor nnz: " << sparse_tensors.back().nnz() << std::endl;
    //Gib das finale Tupel zurück
    return py::make_tuple(py::cast(all_timings), sparse_tensor_to_coo_components(sparse_tensors.back()));
}


py::tuple einsum_v2(
    const std::vector<std::tuple<int, int, std::string>>& ssa_path,
    py::args tensors) {
    
    TimingsList all_timings; //Sammelt alle Zeitmessungen
    
    //Konvertiere Input-Tensoren in SparseTensor
    std::vector<SparseTensor> sparse_tensors;
    sparse_tensors.reserve(tensors.size() + ssa_path.size());
    for (auto& tensor_arg : tensors) {
        if (py::hasattr(tensor_arg, "is_sparse") && tensor_arg.attr("is_sparse").cast<bool>()) {
            SparseTensor st = torch_sparse_to_sparse_tensor(tensor_arg);
            sparse_tensors.push_back(st);
        } else {
            std::cout << "Kein Torch COO Tensor" << std::endl;
        }
    }
    
    //Iteration durch den Pfad
    for (size_t step = 0; step < ssa_path.size(); ++step) {
        const auto& [idx1, idx2, op_name] = ssa_path[step];
        
        if (idx1 >= sparse_tensors.size() || idx2 >= sparse_tensors.size()) {
            throw std::runtime_error("Invalid tensor indices in SSA path");
        }
        
        const SparseTensor& tensor1 = sparse_tensors[idx1];
        const SparseTensor& tensor2 = sparse_tensors[idx2];

        //Berechne die Kontraktion
        auto [result, step_timings] = perform_einsum_v2(op_name, tensor1, tensor2);

        //Speichere Ergebnis und Timings
        sparse_tensors.push_back(result);
        all_timings.insert(all_timings.end(), step_timings.begin(), step_timings.end());
    }
    
    if (sparse_tensors.empty()) {
        return py::make_tuple(py::list(), py::none());
    }
    
    //Gib das finale Tupel zurück
    return py::make_tuple(py::cast(all_timings), sparse_tensor_to_coo_components(sparse_tensors.back()));
}



PYBIND11_MODULE(myeinsum, m) {
    m.doc() = "C++ module to calculate sparse tensor operations";
    m.def("einsum", &einsum, "Perform einsum operation on torch.sparse_coo_tensor tensors",
          py::arg("ssa_path"));
    m.def("einsum_v2", &einsum_v2, "Perform einsum operation on torch.sparse_coo_tensor tensors",
          py::arg("ssa_path"));
}