#include "einsum.h"
#include <iostream>
#include <algorithm>
#include <set>
#include <sstream>
#include <chrono>
#include <map>
#include <unordered_map>
#include <tuple>

#ifdef _OPENMP
#include <omp.h>
#endif

#include <tbb/global_control.h>
#include <tbb/parallel_for.h>
#include <ips4o.hpp>

#include <pybind11/numpy.h>
#include <pybind11/stl.h>
#include <cstdint>

namespace py = pybind11;

using FpMilliseconds = std::chrono::duration<double, std::milli>; //Datentyp zum Messen der Timings

SparseTensor torch_sparse_to_sparse_tensor(py::handle torch_sparse) {
    auto start_time = std::chrono::steady_clock::now();
    
    //Extrahierung der Einträge
    py::object shape_obj = torch_sparse.attr("size")();
    py::array_t<long> indices = torch_sparse.attr("_indices")().cast<py::array_t<long>>();
    py::array_t<double> values = torch_sparse.attr("_values")().cast<py::array_t<double>>();

    //Übertragung der Shape
    std::vector<ssize_t> shape_vec;
    for (auto item : shape_obj) {
        shape_vec.push_back(item.cast<ssize_t>());
    }

    //Instanziiere SparseTensor
    SparseTensor st(shape_vec);

    //Übertrage Werte
    st.values.assign(values.data(), values.data() + values.size());

    auto indices_proxy = indices.unchecked<2>();
    long nnz = indices_proxy.shape(1);
    long ndim = indices_proxy.shape(0);
    
    //Übertrage Koordinaten in gepackter Darstellung
    st.packed_coords.reserve(nnz);
    std::vector<int> current_coord(ndim);
    for (long i = 0; i < nnz; ++i) {
        for (long j = 0; j < ndim; ++j) {
            current_coord[j] = indices_proxy(j, i);
        }
        st.packed_coords.push_back(st.pack_coords(current_coord));
    }
    
    auto end_time = std::chrono::steady_clock::now();
    FpMilliseconds duration = end_time - start_time;
    return st;
}

py::tuple sparse_tensor_to_coo_components(const SparseTensor& tensor) {
    auto start_time = std::chrono::steady_clock::now();

    //Caste Werte Vektor zu Numpy Array
    py::array_t<double> values_arr = py::cast(tensor.values);
    
    //Erstelle leeres ndim x nnz Array für Koordinaten
    int nnz = tensor.nnz();
    py::array_t<int> coords_arr = py::array_t<int>({tensor.ndim, nnz});

    //Hole Zeiger auf Speicher dieses Arrays
    auto coords_ptr = static_cast<int*>(coords_arr.mutable_unchecked<2>().mutable_data(0, 0));
    
    //Befülle mit diesem Zeiger das Array mit den entpackten Koordinaten
    std::vector<int> coord_vec(tensor.ndim);
    for (int i = 0; i < nnz; ++i) {
        tensor.unpack_coords(tensor.packed_coords[i], coord_vec);
        for (int dim = 0; dim < tensor.ndim; ++dim) {
            coords_ptr[dim * nnz + i] = coord_vec[dim];
        }
    }
    
    //Caste Shape Vektor zu Python Tupel
    py::tuple shape_tuple = py::cast(tensor.shape);

    auto end_time = std::chrono::steady_clock::now();
    FpMilliseconds duration = end_time - start_time;

    //Gib ein Tupel (values, coords, shape) zurück, mit dem im Wrapper direkt ein torch.sparse_coo_tensor instanziiert werden kann.
    return py::make_tuple(values_arr, coords_arr, shape_tuple);
}

SparseTensor sparse_bmm_bji_bjk(const SparseTensor& A, const SparseTensor& B) {
    if (A.ndim != 3 || B.ndim != 3) {
        throw std::runtime_error("Beide Tensoren müssen 3-dimensional sein.");
    }
    if (A.shape[0] != B.shape[0] || A.shape[1] != B.shape[1]) {
        throw std::runtime_error("Inkompatible Batch- (b) oder innere (j) Dimensionen.");
    }
    
    //Hilfsstruktur für Arbeitsblöcke
    struct BJ_Task {
        int b, j;
        size_t a_start, a_end;
        size_t b_start, b_end;
    };
    std::vector<BJ_Task> tasks;
    
    size_t a_idx = 0;
    size_t b_idx = 0;
    std::vector<int> a_coords_main(3), b_coords_main(3);

    //Finde alle übereinstimmenden (b,j) Blöcke (Aufgaben für die Parallelisierung)
    while (a_idx < A.nnz() && b_idx < B.nnz()) {
        A.unpack_coords(A.packed_coords[a_idx], a_coords_main);
        B.unpack_coords(B.packed_coords[b_idx], b_coords_main);
        
        int a_b = a_coords_main[0], a_j = a_coords_main[1];
        int b_b = b_coords_main[0], b_j = b_coords_main[1];
        
        if (a_b < b_b || (a_b == b_b && a_j < b_j)) {
            a_idx++; //Erhöhe Index in A solange bis b und j zur aktuellen Stelle in B gleich sind, falls a_idx hinten liegt
        } else if (b_b < a_b || (a_b == b_b && b_j < a_j)) {
            b_idx++; //Erhöhe Index in B solange bis b und j zur aktuellen Stelle in A gleich sind, falls b_idx hinten liegt
        } else {
            //Startindex in a und b gefunden
            size_t a_start = a_idx;
            //Erhöhe a_idx bis b oder j nicht mehr übereinstimmt
            while (a_idx < A.nnz() && (A.unpack_coords(A.packed_coords[a_idx], a_coords_main), a_coords_main[0] == a_b && a_coords_main[1] == a_j)) {
                a_idx++;
            }
            
            size_t b_start = b_idx;
            //Erhöhe b_idx bis b oder j nicht mehr übereinstimmt
            while (b_idx < B.nnz() && (B.unpack_coords(B.packed_coords[b_idx], b_coords_main), b_coords_main[0] == b_b && b_coords_main[1] == b_j)) {
                b_idx++;
            }
            
            //Füge neue Aufgabe mit ermitteltem Bereich dazu
            tasks.push_back({a_b, a_j, a_start, a_idx, b_start, b_idx});
        }
    }

    //Parallele Verarbeitung der Aufgaben
    std::vector<SparseTensor> local_results;
    #pragma omp parallel
    {
        int thread_id = omp_get_thread_num();
        #pragma omp single
        {
            local_results.resize(omp_get_num_threads(), SparseTensor({A.shape[0], A.shape[2], B.shape[2]}));
        }

        std::vector<int> a_coords_local(3), b_coords_local(3);
        //Tasks werden auf die Threads aufgeteilt
        #pragma omp for schedule(static)
        for (size_t i = 0; i < tasks.size(); ++i) {
            const auto& task = tasks[i];

            //Bilde äußeres Produkt über i x k für diesen BJ-Block für spätere Aggregation
            for (size_t a_pos = task.a_start; a_pos < task.a_end; ++a_pos) {
                A.unpack_coords(A.packed_coords[a_pos], a_coords_local);
                double a_val = A.values[a_pos];
                //Für jedes i: Multipliziere mit jedem k und packe das zwischenergebnis für neuen bik Eintrag in die Map
                for (size_t b_pos = task.b_start; b_pos < task.b_end; ++b_pos) {
                    B.unpack_coords(B.packed_coords[b_pos], b_coords_local);
                    double b_val = B.values[b_pos];
                    
                    uint128_t c_key = local_results[thread_id].pack_coords({task.b, a_coords_local[2], b_coords_local[2]});
                    local_results[thread_id].packed_coords.push_back(c_key);
                    local_results[thread_id].values.push_back(a_val * b_val);
                }
            }
        }
    }

    std::unordered_map<uint128_t, double> aggregated_results;

    //Sammle Ergebnisse der Threads sequenziell
    for (const auto& local_C : local_results) {
        for (size_t i = 0; i < local_C.nnz(); ++i) {
            uint128_t key = local_C.packed_coords[i];
            double value = local_C.values[i];
            aggregated_results[key] += value;
        }
    }
    
    //Instanziiere Ergebnis-SparseTensor
    SparseTensor C({A.shape[0], A.shape[2], B.shape[2]});
    size_t total_nnz = 0;
    for(const auto& local_C : local_results) {
        total_nnz += local_C.nnz();
    }
    C.packed_coords.reserve(total_nnz);
    C.values.reserve(total_nnz);

    //Übertrage Koordinaten und Werte
    for (const auto& pair : aggregated_results) {
        C.packed_coords.push_back(pair.first); // Der Schlüssel (gepackte Koordinate)
        C.values.push_back(pair.second);      // Der Wert (die Summe)
    }

    return C;
}

SparseTensor sparse_bmm_bij_bkj(const SparseTensor& A, const SparseTensor& B) {
    if (A.ndim != 3 || B.ndim != 3) throw std::runtime_error("Beide Tensoren müssen 3-dimensional sein.");
    if (A.shape[0] != B.shape[0] || A.shape[2] != B.shape[2]) throw std::runtime_error("Inkompatible Dimensionen.");

    //Hilfsstruktur für Arbeitsblöcke
    struct BatchTask {
        int b;
        size_t a_start, a_end;
        size_t b_start, b_end;
    };
    std::vector<BatchTask> tasks;
    
    size_t a_ptr = 0, b_ptr = 0;
    std::vector<int> a_coords_main(3), b_coords_main(3);
    while (a_ptr < A.nnz() && b_ptr < B.nnz()) {
        A.unpack_coords(A.packed_coords[a_ptr], a_coords_main);
        B.unpack_coords(B.packed_coords[b_ptr], b_coords_main);

        if (a_coords_main[0] < b_coords_main[0]) { a_ptr++; continue; }//Solange a_ptr auf kleineres b als b_ptr zeigt -> erhöhen
        if (b_coords_main[0] < a_coords_main[0]) { b_ptr++; continue; }//Solange b_ptr auf kleineres b als a_ptr zeigt -> erhöhen

        int b = a_coords_main[0];
        //Bei gleichen b->start des Blocks gefunden
        size_t a_batch_start = a_ptr;
        size_t b_batch_start = b_ptr;
        while (a_ptr < A.nnz() && (A.unpack_coords(A.packed_coords[a_ptr], a_coords_main), a_coords_main[0] == b)) a_ptr++; //erhöhe a_ptr bis neues b erreicht
        size_t a_batch_end = a_ptr;
        while (b_ptr < B.nnz() && (B.unpack_coords(B.packed_coords[b_ptr], b_coords_main), b_coords_main[0] == b)) b_ptr++; //erhöhe b_ptr bis neues b erreicht
        size_t b_batch_end = b_ptr;
        
        //Füge ermittelten Block hinzu
        tasks.push_back({b, a_batch_start, a_batch_end, b_batch_start, b_batch_end});
    }

    //Parallele Verarbeitung der Aufgaben
    std::vector<SparseTensor> local_results;
    #pragma omp parallel
    {
        int thread_id = omp_get_thread_num();
        #pragma omp single
        {
            //Jeder Thread bekommt eigenen SparseTensor
            local_results.resize(omp_get_num_threads(), SparseTensor({A.shape[0], A.shape[1], B.shape[1]}));
        }
        //Hilfsvektoren zum Entpacken
        std::vector<int> a_coords(3), b_coords(3);

        //Parallele Abarbeitung der Tasks
        #pragma omp for schedule(dynamic)
        for (size_t i = 0; i < tasks.size(); ++i) {
            const auto& task = tasks[i];
            size_t a_i_ptr = task.a_start;
            while (a_i_ptr < task.a_end) {
                A.unpack_coords(A.packed_coords[a_i_ptr], a_coords);

                //Ermittlung von (b,i) Block in A
                int current_i = a_coords[1];
                size_t a_i_block_start = a_i_ptr;
                while (a_i_ptr < task.a_end && (A.unpack_coords(A.packed_coords[a_i_ptr], a_coords), a_coords[0] == task.b && a_coords[1] == current_i)) a_i_ptr++;
                size_t a_i_block_end = a_i_ptr;

                //Für jede Zeile (b,i) in A wird durch jede Zeile (b,k) durch B geloopt 
                size_t b_k_ptr = task.b_start;
                while (b_k_ptr < task.b_end) {

                    //Ermittlung von (b,k) Block in B
                    B.unpack_coords(B.packed_coords[b_k_ptr], b_coords);
                    int current_k = b_coords[1];
                    size_t b_k_block_start = b_k_ptr;
                    while (b_k_ptr < task.b_end && (B.unpack_coords(B.packed_coords[b_k_ptr], b_coords), b_coords[0] == task.b && b_coords[1] == current_k)) b_k_ptr++;
                    size_t b_k_block_end = b_k_ptr;

                    double sum_val = 0;
                    size_t j_ptr_a = a_i_block_start, j_ptr_b = b_k_block_start;
                    
                    //Hole aktuelle Koordinaten 
                    if (j_ptr_a < a_i_block_end && j_ptr_b < b_k_block_end) {
                        A.unpack_coords(A.packed_coords[j_ptr_a], a_coords);
                        B.unpack_coords(B.packed_coords[j_ptr_b], b_coords);
                    }
                    //Gehe Elemente des (b,i) und (b,k) Blocks durch und suche nach gleichen j
                    while (j_ptr_a < a_i_block_end && j_ptr_b < b_k_block_end) {
                        if (a_coords[2] < b_coords[2]) {
                            if (++j_ptr_a < a_i_block_end) A.unpack_coords(A.packed_coords[j_ptr_a], a_coords);
                        } else if (b_coords[2] < a_coords[2]) {
                            if (++j_ptr_b < b_k_block_end) B.unpack_coords(B.packed_coords[j_ptr_b], b_coords);
                        } else {
                            //Bei gleichem j: Multipliziere Einträge und addiere zum Endwert von (b,i,k) auf
                            sum_val += A.values[j_ptr_a] * B.values[j_ptr_b];
                            if (++j_ptr_a < a_i_block_end) A.unpack_coords(A.packed_coords[j_ptr_a], a_coords);
                            if (++j_ptr_b < b_k_block_end) B.unpack_coords(B.packed_coords[j_ptr_b], b_coords);
                        }
                    }
                    //Wenn Wert errechnet füge ihn dem Thread-Spezifischen Tensor hinzu
                    if (sum_val != 0.0f) {
                        uint128_t c_key = local_results[thread_id].pack_coords({task.b, current_i, current_k});
                        local_results[thread_id].packed_coords.push_back(c_key);
                        local_results[thread_id].values.push_back(sum_val);
                    }
                }
            }
        }
    }

    //Erstelle Ergebnistensor
    SparseTensor C({A.shape[0], A.shape[1], B.shape[1]});
    size_t total_nnz = 0;
    for(const auto& local_C : local_results) {
        total_nnz += local_C.nnz();
    }
    C.packed_coords.reserve(total_nnz);
    C.values.reserve(total_nnz);

    //Sammle die Ergebnisse der einzelnen Threads im Ergebnistensor
    for(const auto& local_C : local_results) {
        C.packed_coords.insert(C.packed_coords.end(), local_C.packed_coords.begin(), local_C.packed_coords.end());
        C.values.insert(C.values.end(), local_C.values.begin(), local_C.values.end());
    }
    
    return C;
}  

//Struktur zum speichern der Indexpartition
struct IndexPartition {
    std::set<char> batch, contract, left_sum, right_sum, left_kept, right_kept;
    std::vector<char> sigma1, sigma2, sigma3;
    std::map<char, ssize_t> index_shapes;
};


//Funktion zur Partitionierung der Indizes
IndexPartition partition_einsum_indices(const std::string& einsum_notation, const SparseTensor& A, const SparseTensor& B) {
    IndexPartition result;

    //Prüfung ob Syntax korrekt
    size_t arrow_pos = einsum_notation.find("->");
    if (arrow_pos == std::string::npos) throw std::invalid_argument("Einsum notation must contain '->'");
    size_t comma_pos = einsum_notation.find(",");
    if (comma_pos == std::string::npos || comma_pos > arrow_pos) throw std::invalid_argument("Einsum notation must contain ',' before '->'");
    
    //Splitten und Formatierung des Ausdrucks in drei Strings
    std::string s1 = einsum_notation.substr(0, comma_pos);
    std::string s2 = einsum_notation.substr(comma_pos + 1, arrow_pos - comma_pos - 1);
    std::string s3 = einsum_notation.substr(arrow_pos + 2);
    s1.erase(std::remove_if(s1.begin(), s1.end(), ::isspace), s1.end());
    s2.erase(std::remove_if(s2.begin(), s2.end(), ::isspace), s2.end());
    s3.erase(std::remove_if(s3.begin(), s3.end(), ::isspace), s3.end());
    if (s1.length() != A.ndim) throw std::invalid_argument("Number of indices in sigma1 must match tensor A dimensions");
    if (s2.length() != B.ndim) throw std::invalid_argument("Number of indices in sigma2 must match tensor B dimensions");

    //Vektorisierung dieser Strings für Ergebnisstruktur
    result.sigma1 = std::vector<char>(s1.begin(), s1.end());
    result.sigma2 = std::vector<char>(s2.begin(), s2.end());
    result.sigma3 = std::vector<char>(s3.begin(), s3.end());
    
    //Ermittlung der Einzelnen Indexklassen
    std::set<char> i1(s1.begin(), s1.end()), i2(s2.begin(), s2.end()), i3(s3.begin(), s3.end());
    for (char idx : i1) if (i2.count(idx) && i3.count(idx)) result.batch.insert(idx);
    for (char idx : i1) if (i2.count(idx) && !i3.count(idx)) result.contract.insert(idx);
    for (char idx : i1) if (!i2.count(idx) && !i3.count(idx)) result.left_sum.insert(idx);
    for (char idx : i2) if (!i1.count(idx) && !i3.count(idx)) result.right_sum.insert(idx);
    for (char idx : i1) if (!i2.count(idx) && i3.count(idx)) result.left_kept.insert(idx);
    for (char idx : i2) if (!i1.count(idx) && i3.count(idx)) result.right_kept.insert(idx);

    //Setzen der Shapes und Prüfung dass es keinen Dimension Mismatch gibt
    for (size_t i = 0; i < s1.length(); ++i) result.index_shapes[s1[i]] = A.shape[i];
    for (size_t i = 0; i < s2.length(); ++i) {
        char idx = s2[i];
        if (result.index_shapes.count(idx) && result.index_shapes[idx] != B.shape[i]) {
            throw std::invalid_argument("Dimension mismatch for index.");
        }
        result.index_shapes[idx] = B.shape[i];
    }
    return result;
}

//Funktion zur Eliminierung wiederholter Indizes
SparseTensor clear_repeated_indices(const SparseTensor& tensor, std::vector<char>& indices) {
    if (indices.size() != tensor.ndim) throw std::invalid_argument("Number of indices must match tensor dimension");
    
    //Bestimmung der Positionen der einzelnen Indizes
    std::map<char, std::vector<int>> index_positions;
    for (int i = 0; i < indices.size(); ++i) index_positions[indices[i]].push_back(i);

    //Ermittlung ob Indizes doppelt auftreten
    bool has_duplicates = false;
    for (const auto& pair : index_positions) if (pair.second.size() > 1) has_duplicates = true;
    if (!has_duplicates) return tensor; //Wenn nicht -> Tensor unverändert zurückgeben
    
    //Erstelle Liste der indizes ohne dopplung
    std::vector<char> unique_indices;
    std::set<char> seen_indices;
    for (char idx : indices) if (seen_indices.find(idx) == seen_indices.end()) {
        unique_indices.push_back(idx);
        seen_indices.insert(idx);
    }
    
    //Ermittlung der neuen Shape mit gleichzeitiger Prüfung auf Dimension Mismatch
    std::vector<ssize_t> new_shape;
    for (char idx : unique_indices) {
        const auto& positions = index_positions[idx];
        ssize_t dim_size = tensor.shape[positions[0]];
        for (int pos : positions) if (tensor.shape[pos] != dim_size) throw std::invalid_argument("Dimensions for repeated indices must be equal");
        new_shape.push_back(dim_size);
    }

    //Instanziiere Ergebnistensor
    SparseTensor result(new_shape);
    result.packed_coords.reserve(tensor.nnz());
    result.values.reserve(tensor.nnz());

    //Hilfsvektoren fürs Entpacken
    std::vector<int> coords(tensor.ndim), new_coords(result.ndim);

    //Iteriere durch jedes Tensor-Element
    for (int elem_idx = 0; elem_idx < tensor.nnz(); ++elem_idx) {
        tensor.unpack_coords(tensor.packed_coords[elem_idx], coords);
        bool is_diagonal = true;
        //Prüfe jeden Index
        for (const auto& pair : index_positions) {
            //Falls Index mehrfach auftritt, wird untersucht, ob die Koordinaten des Elements an diesen Stellen übereinstimmen
            if (pair.second.size() > 1) {
                int coord_value = coords[pair.second[0]];
                for (size_t i = 1; i < pair.second.size(); ++i) if (coords[pair.second[i]] != coord_value) is_diagonal = false;
                if (!is_diagonal) break; //Falls nicht: Abbruch
            }
        }
        //Falls ja: Übernehme Element ohne doppelte Indizes in neuen Tensor
        if (is_diagonal) {
            for(size_t i = 0; i < unique_indices.size(); ++i) {
                new_coords[i] = coords[index_positions[unique_indices[i]][0]];
            }
            result.add_element(new_coords, tensor.values[elem_idx]);
        }
    }

    indices = unique_indices;
    return result;
}

//Funktion zur Eliminierung einzelner Achsen durch Summation
SparseTensor eliminate_summed_indices(const SparseTensor& tensor, const std::set<char>& summed_indices, std::vector<char>& all_indices) {
    //Falls keine zu eliminierenden Achsen -> originaltensor zurückgeben
    if (summed_indices.empty()) return tensor;
    if (all_indices.size() != tensor.ndim) throw std::invalid_argument("Number of all_indices must match tensor dimension");

    //Finde die Positionen der zu eliminierenden Achsen
    std::vector<int> sum_axes, keep_axes;
    for (const char& idx : summed_indices) {
        auto it = std::find(all_indices.begin(), all_indices.end(), idx);
        if (it == all_indices.end()) throw std::invalid_argument("Summed index not found");
        sum_axes.push_back(std::distance(all_indices.begin(), it));
    }

    //Finde die Positionen der behaltenen Achsen
    for (int i = 0; i < tensor.ndim; ++i) if (std::find(sum_axes.begin(), sum_axes.end(), i) == sum_axes.end()) keep_axes.push_back(i);
    
    //Erstelle Ergebnis-SparseTensor mit Ziel-Shape
    std::vector<ssize_t> new_shape;
    for (int axis : keep_axes) new_shape.push_back(tensor.shape[axis]);
    SparseTensor result(new_shape);

    //Erstelle Map zur Aggregation der Werte auf den Achsen
    std::unordered_map<uint128_t, double> grouped_values;
    //Hilfsvektor zum entpacken
    std::vector<int> coords(tensor.ndim);

    //Für jedes Element
    for (int elem_idx = 0; elem_idx < tensor.nnz(); ++elem_idx) {
        //Füge Behaltene Koordinaten des Elements in Vektor ein
        tensor.unpack_coords(tensor.packed_coords[elem_idx], coords);
        std::vector<int> key_coords;
        for (int axis : keep_axes) key_coords.push_back(coords[axis]);
        
        //Addiere den Wert des Element auf den Map-Eintrag von den Zielkoordinaten
        grouped_values[result.pack_coords(key_coords)] += tensor.values[elem_idx];
    }
    
    //Übertrage Einträge der Map in neuen Tensor
    result.packed_coords.reserve(grouped_values.size());
    result.values.reserve(grouped_values.size());
    for (const auto& pair : grouped_values) {
        result.packed_coords.push_back(pair.first);
        result.values.push_back(pair.second);
    }

    //Entferne eliminierte Indizes aus all_indices
    all_indices.erase(std::remove_if(all_indices.begin(), all_indices.end(), 
        [&summed_indices](char c) { return summed_indices.count(c); }), all_indices.end());
    
    return result;
}

//Funktion zum transponieren und je nach flag anschließender Sortierung
std::tuple<SparseTensor, double, double> transpose_and_sort(
    const SparseTensor& tensor,
    const std::vector<char>& current_indices,
    const std::vector<char>& target_indices,
    bool perform_sort
) {
    if (current_indices.size() != tensor.ndim || target_indices.size() != tensor.ndim) {
        throw std::invalid_argument("Index counts must match tensor dimension");
    }

    auto start_time_transpose = std::chrono::steady_clock::now();
    
    //Erstellt Map um Position jedes Index schnell nachschlagen zu können
    std::map<char, int> current_pos_map;
    for (size_t i = 0; i < current_indices.size(); ++i) current_pos_map[current_indices[i]] = i;
    
    //Erstelle daraus und den target_indices den Permutationsvektor
    std::vector<int> permutation(tensor.ndim);
    for (size_t i = 0; i < target_indices.size(); ++i) {
        auto it = current_pos_map.find(target_indices[i]);
        if (it == current_pos_map.end()) throw std::invalid_argument("Target index not found");
        permutation[i] = it->second;
    }
    
    //Erstelle Ergebnistensor
    std::vector<ssize_t> new_shape(tensor.ndim);
    for (int i = 0; i < tensor.ndim; ++i) new_shape[i] = tensor.shape[permutation[i]];
    SparseTensor result(new_shape);

    //Frühzeitiger Abbruch
    if (tensor.nnz() == 0) return {result, 0.0, 0.0};

    SparseTensor transposed_tensor(new_shape);
    
    //Struktur für späteres Sortieren
    struct CoordValue {
        uint128_t packed_coord;
        double value;
        bool operator<(const CoordValue& other) const {return packed_coord < other.packed_coord; }
    };
    std::vector<CoordValue> sorted_entries(tensor.nnz());
    
    //Parallel für jedes Element
    #pragma omp parallel for
    for (int elem_idx = 0; elem_idx < tensor.nnz(); ++elem_idx) {
        //Entpacke Koordinaten
        std::vector<int> original_coords(tensor.ndim);
        tensor.unpack_coords(tensor.packed_coords[elem_idx], original_coords);
        
        //Permutiere sie
        std::vector<int> new_coords(tensor.ndim);
        for (int i = 0; i < tensor.ndim; ++i) {
            new_coords[i] = original_coords[permutation[i]];
        }
        //Speichere sie als CoordValue
        sorted_entries[elem_idx] = {transposed_tensor.pack_coords(new_coords), tensor.values[elem_idx]};
    }
    auto end_time_transpose = std::chrono::steady_clock::now();
    FpMilliseconds transpose_duration = end_time_transpose - start_time_transpose;

    //Sortiere
    FpMilliseconds sort_duration(0.0); //Standardmäßig 0, falls nicht sortiert wird.
    if (perform_sort) {
        auto start_time_sort = std::chrono::steady_clock::now();
        ips4o::parallel::sort(sorted_entries.begin(), sorted_entries.end());
        auto end_time_sort = std::chrono::steady_clock::now();
        FpMilliseconds sort_duration = end_time_sort - start_time_sort;
    }

    //Übertrage Werte in Ergebnistensor
    result.packed_coords.resize(tensor.nnz());
    result.values.resize(tensor.nnz());
    for(int i = 0; i < tensor.nnz(); ++i) {
        result.packed_coords[i] = sorted_entries[i].packed_coord;
        result.values[i] = sorted_entries[i].value;
    }
    
    return {result, transpose_duration.count(), sort_duration.count()};
}

//Funktion zum reshape von Tensoren
SparseTensor reshape(const SparseTensor& tensor, const std::vector<ssize_t>& new_shape) {

    //Überprüfung von Start- und Zielgröße
    ssize_t original_size = 1; for (ssize_t dim : tensor.shape) original_size *= dim;
    ssize_t new_size = 1; for (ssize_t dim : new_shape) new_size *= dim;
    if (original_size != new_size) throw std::invalid_argument("New shape must have the same number of elements.");

    //Erstelle Zieltensor
    SparseTensor result(new_shape);
    const size_t num_non_zero = tensor.nnz();
    if (num_non_zero == 0) return result;
    result.values.resize(num_non_zero);
    result.packed_coords.resize(num_non_zero);

    //Berechne Strides für Start- und Zieltensor
    std::vector<ssize_t> old_strides(tensor.ndim), new_strides(result.ndim);
    if (tensor.ndim > 0) {
        old_strides.back() = 1;
        for (int i = tensor.ndim - 2; i >= 0; --i) old_strides[i] = old_strides[i + 1] * tensor.shape[i + 1];
    }
    if (result.ndim > 0) {
        new_strides.back() = 1;
        for (int i = result.ndim - 2; i >= 0; --i) new_strides[i] = new_strides[i + 1] * new_shape[i + 1];
    }

    //Parallel für jedes Element
    #pragma omp parallel for
    for (int elem_idx = 0; elem_idx < num_non_zero; ++elem_idx) {
        //Entpacke Koordinaten
        std::vector<int> old_coords(tensor.ndim);
        tensor.unpack_coords(tensor.packed_coords[elem_idx], old_coords);
        
        //Berechne flachen Index
        ssize_t flat_index = 0;
        for (int i = 0; i < tensor.ndim; ++i) flat_index += old_coords[i] * old_strides[i];
        
        //Berechne neue Koordinaten
        std::vector<int> new_coords(result.ndim);
        for (int i = 0; i < result.ndim; ++i) new_coords[i] = (flat_index / new_strides[i]) % new_shape[i];
        
        //Füge Ergebnistensor dieses Element hinzu
        result.packed_coords[elem_idx] = result.pack_coords(new_coords);
        result.values[elem_idx] = tensor.values[elem_idx];
    }
    
    return result;
}

//Hilfsfunktionen
std::vector<ssize_t> calculate_shape(const std::vector<char>& indices, const IndexPartition& ip) {
    std::vector<ssize_t> shape; shape.reserve(indices.size());
    for (char idx : indices) shape.push_back(ip.index_shapes.at(idx));
    return shape;
}
ssize_t calculate_dimension_product(const std::set<char>& indices, const IndexPartition& ip) {
    ssize_t product = 1;
    for (char idx : indices) product *= ip.index_shapes.at(idx);
    return product;
}
std::vector<char> combine_char_sets(const std::set<char>& s1, const std::set<char>& s2, const std::set<char>& s3) {
    std::vector<char> result; result.reserve(s1.size() + s2.size() + s3.size());
    result.insert(result.end(), s1.begin(), s1.end());
    result.insert(result.end(), s2.begin(), s2.end());
    result.insert(result.end(), s3.begin(), s3.end());
    return result;
}


//einsum pipeline mit bmm kernel bji,bjk->bik
std::pair<SparseTensor, TimingsList> perform_einsum(
    const std::string& op_name,
    const SparseTensor& tensor_a,
    const SparseTensor& tensor_b) {

    TimingsList timings;
    static tbb::global_control gc(tbb::global_control::max_allowed_parallelism, std::thread::hardware_concurrency());
    
    //Indexpartition
    IndexPartition ip = partition_einsum_indices(op_name, tensor_a, tensor_b);
    
    //Diagonalisierung
    auto start_time = std::chrono::steady_clock::now();
    SparseTensor tensor_a_cleared = clear_repeated_indices(tensor_a, ip.sigma1);
    SparseTensor tensor_b_cleared = clear_repeated_indices(tensor_b, ip.sigma2);
    auto end_time = std::chrono::steady_clock::now();
    timings.emplace_back("Clear Repeated Indices", FpMilliseconds(end_time - start_time).count());
    
    //Summierung
    start_time = std::chrono::steady_clock::now();
    SparseTensor tensor_a_reduced = eliminate_summed_indices(tensor_a_cleared, ip.left_sum, ip.sigma1);
    SparseTensor tensor_b_reduced = eliminate_summed_indices(tensor_b_cleared, ip.right_sum, ip.sigma2);
    end_time = std::chrono::steady_clock::now();
    timings.emplace_back("Eliminate Summed Indices", FpMilliseconds(end_time - start_time).count());

    //Transponierung und Sortierung
    double total_transpose_time = 0.0;
    double total_sort_time = 0.0;
    std::vector<char> target_a = combine_char_sets(ip.batch, ip.contract, ip.left_kept);
    std::vector<char> target_b = combine_char_sets(ip.batch, ip.contract, ip.right_kept);
    auto [tensor_a_transposed, trans_time_a, sort_time_a] = transpose_and_sort(tensor_a_reduced, ip.sigma1, target_a, true);
    total_transpose_time += trans_time_a;
    total_sort_time += sort_time_a;
    auto [tensor_b_transposed, trans_time_b, sort_time_b] = transpose_and_sort(tensor_b_reduced, ip.sigma2, target_b, true);
    total_transpose_time += trans_time_b;
    total_sort_time += sort_time_b;
    timings.emplace_back("Transpose (pre-BMM)", total_transpose_time);
    timings.emplace_back("Sort (pre-BMM)", total_sort_time);

    //Reshape
    start_time = std::chrono::steady_clock::now();
    std::vector<ssize_t> a_shape = {calculate_dimension_product(ip.batch, ip), calculate_dimension_product(ip.contract, ip), calculate_dimension_product(ip.left_kept, ip)};
    std::vector<ssize_t> b_shape = {calculate_dimension_product(ip.batch, ip), calculate_dimension_product(ip.contract, ip), calculate_dimension_product(ip.right_kept, ip)};
    SparseTensor tensor_a_prepared = reshape(tensor_a_transposed, a_shape);
    SparseTensor tensor_b_prepared = reshape(tensor_b_transposed, b_shape);
    end_time = std::chrono::steady_clock::now();
    timings.emplace_back("Reshape (pre-BMM)", FpMilliseconds(end_time - start_time).count());
    
    //BMM
    start_time = std::chrono::steady_clock::now();
    SparseTensor tensor_c = sparse_bmm_bji_bjk(tensor_a_prepared, tensor_b_prepared);
    end_time = std::chrono::steady_clock::now();
    timings.emplace_back("BMM (bji,bjk->bik)", FpMilliseconds(end_time - start_time).count());

    //Reshape
    start_time = std::chrono::steady_clock::now();
    std::vector<char> target_c_indices = combine_char_sets(ip.batch, ip.left_kept, ip.right_kept);
    SparseTensor tensor_c_shaped = reshape(tensor_c, calculate_shape(target_c_indices, ip));
    end_time = std::chrono::steady_clock::now();
    timings.emplace_back("Reshape (post-BMM)", FpMilliseconds(end_time - start_time).count());
    
    //Transponierung ohne Sortierung
    auto [result, final_trans_time, final_sort_time] = transpose_and_sort(tensor_c_shaped, target_c_indices, ip.sigma3, false);
    timings.emplace_back("Transpose (final)", final_trans_time);
    
    return {result, timings};
}

//einsum pipeline mit bmm kernel bij,bkj->bik
std::pair<SparseTensor, TimingsList> perform_einsum_v2(
    const std::string& op_name,
    const SparseTensor& tensor_a,
    const SparseTensor& tensor_b) {

    TimingsList timings;
    static tbb::global_control gc(tbb::global_control::max_allowed_parallelism, std::thread::hardware_concurrency());
    
    //Indexpartition
    IndexPartition ip = partition_einsum_indices(op_name, tensor_a, tensor_b);
    
    //Diagonalisierung
    auto start_time = std::chrono::steady_clock::now();
    SparseTensor tensor_a_cleared = clear_repeated_indices(tensor_a, ip.sigma1);
    SparseTensor tensor_b_cleared = clear_repeated_indices(tensor_b, ip.sigma2);
    auto end_time = std::chrono::steady_clock::now();
    timings.emplace_back("Clear Repeated Indices", FpMilliseconds(end_time - start_time).count());
    
    //Summierung
    start_time = std::chrono::steady_clock::now();
    SparseTensor tensor_a_reduced = eliminate_summed_indices(tensor_a_cleared, ip.left_sum, ip.sigma1);
    SparseTensor tensor_b_reduced = eliminate_summed_indices(tensor_b_cleared, ip.right_sum, ip.sigma2);
    end_time = std::chrono::steady_clock::now();
    timings.emplace_back("Eliminate Summed Indices", FpMilliseconds(end_time - start_time).count());

    //Transponierung und Sortierung
    double total_transpose_time = 0.0;
    double total_sort_time = 0.0;
    std::vector<char> target_a = combine_char_sets(ip.batch, ip.left_kept, ip.contract);
    std::vector<char> target_b = combine_char_sets(ip.batch, ip.right_kept, ip.contract);
    auto [tensor_a_transposed, trans_time_a, sort_time_a] = transpose_and_sort(tensor_a_reduced, ip.sigma1, target_a, true);
    total_transpose_time += trans_time_a;
    total_sort_time += sort_time_a;
    auto [tensor_b_transposed, trans_time_b, sort_time_b] = transpose_and_sort(tensor_b_reduced, ip.sigma2, target_b, true);
    total_transpose_time += trans_time_b;
    total_sort_time += sort_time_b;
    timings.emplace_back("Transpose (pre-BMM)", total_transpose_time);
    timings.emplace_back("Sort (pre-BMM)", total_sort_time);

    //Reshape
    start_time = std::chrono::steady_clock::now();
    std::vector<ssize_t> a_shape = {calculate_dimension_product(ip.batch, ip), calculate_dimension_product(ip.left_kept, ip), calculate_dimension_product(ip.contract, ip)};
    std::vector<ssize_t> b_shape = {calculate_dimension_product(ip.batch, ip), calculate_dimension_product(ip.right_kept, ip), calculate_dimension_product(ip.contract, ip)};
    SparseTensor tensor_a_prepared = reshape(tensor_a_transposed, a_shape);
    SparseTensor tensor_b_prepared = reshape(tensor_b_transposed, b_shape);
    end_time = std::chrono::steady_clock::now();
    timings.emplace_back("Reshape (pre-BMM)", FpMilliseconds(end_time - start_time).count());
    
    //BMM
    start_time = std::chrono::steady_clock::now();
    SparseTensor tensor_c = sparse_bmm_bij_bkj(tensor_a_prepared, tensor_b_prepared);
    end_time = std::chrono::steady_clock::now();
    timings.emplace_back("BMM (bij,bkj->bik)", FpMilliseconds(end_time - start_time).count());

    //Reshape
    start_time = std::chrono::steady_clock::now();
    std::vector<char> target_c_indices = combine_char_sets(ip.batch, ip.left_kept, ip.right_kept);
    SparseTensor tensor_c_shaped = reshape(tensor_c, calculate_shape(target_c_indices, ip));
    end_time = std::chrono::steady_clock::now();
    timings.emplace_back("Reshape (post-BMM)", FpMilliseconds(end_time - start_time).count());
    
    //Transponierung ohne Sortierung
    auto [result, final_trans_time, final_sort_time] = transpose_and_sort(tensor_c_shaped, target_c_indices, ip.sigma3, false);
    timings.emplace_back("Transpose (final)", final_trans_time);
    
    return {result, timings};
}