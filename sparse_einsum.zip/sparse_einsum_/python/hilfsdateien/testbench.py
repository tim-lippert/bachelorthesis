import numpy as np
import torch


import os
import sys
import inspect

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir) 

from wrapper import sparse_einsum_v1, sparse_einsum_v2


#from wrapper import sparse_einsum
def np_to_torch_sparse(np_array):
    """
    Konvertiert ein NumPy-Array in einen PyTorch sparse_coo_tensor.
    
    Args:
        np_array: Das zu konvertierende NumPy-Array.
        
    Returns:
        Ein torch.sparse_coo_tensor.
    """
    # Finde die Indizes der Nicht-Null-Elemente
    non_zero_indices = np.nonzero(np_array)
    
    # Extrahiere die Werte an diesen Indizes
    values = np_array[non_zero_indices]
    
    # Konvertiere die Indizes und Werte in PyTorch-Tensoren
    indices_tensor = torch.tensor(np.array(non_zero_indices), dtype=torch.long)
    values_tensor = torch.tensor(values, dtype=torch.float32)
    
    # Erstelle den PyTorch Sparse COO Tensor
    sparse_tensor = torch.sparse_coo_tensor(
        indices=indices_tensor,
        values=values_tensor,
        size=np_array.shape
    )
    
    return sparse_tensor

def test_myeinsum_torch():
    """Testet sparse_einsum mit PyTorch sparse_coo_tensors"""
    print("\nTesting sparse_einsum with PyTorch sparse_coo_tensors:")
    
    test_cases = [
        ("Standard-Matrixmultiplikation", "ij,jk->ik", (3, 4), (4, 5)),
        ("Leeres Ergebnis", "ij,kl->", (3, 4), (4, 5)),
        ("Elementweise Multiplikation", "ij,ij->ij", (3, 4), (3, 4)),
        ("Elementweise Multiplikation mit summed_index", "ijk,ij->ij", (3, 4,4), (3, 4)),
        ("Diagonalisierung im ersten Operanden", "ii,ij->ij", (4, 4), (4, 3)),
        ("Kontraktion mit drei Indizes in A", "ijk,kl->ijl", (2, 3, 4), (4, 5)),
        ("Vektor-Kontraktion 1", "ij,j->i", (5, 6), (6,)),
        ("Vektor-Kontraktion 2", "i,ij->j", (7,), (7, 3)),
        ("Kontraktion über den zweiten Index", "ij,kj->ik", (3, 4), (5, 4)),
        ("Outer Product ohne gemeinsame Indizes", "ij,kl->ijkl", (2, 3), (4, 5)),
        ("Diagonalisierung in beiden Operanden", "ii,ii->i", (4, 4), (4, 4)),
        ("Hochdimensionale Tensorenkontraktion", "abcde,abcef->abcdf", (2, 3, 4, 5, 6), (2, 3, 4, 6, 7)),
    ]

    for i, (name, einsum_str, shape_a, shape_b) in enumerate(test_cases, 1):
        print(f"Test {i}: {name}")
        A = np.random.rand(*shape_a).astype(np.float32)
        B = np.random.rand(*shape_b).astype(np.float32)

        torch_sparse_A = np_to_torch_sparse(A)
        torch_sparse_B = np_to_torch_sparse(B)
        
        ssa_path = [(0, 1, einsum_str)]
        
        result_sparse, timings = sparse_einsum_v1(ssa_path, torch_sparse_A, torch_sparse_B)
        result_dense = result_sparse.to_dense().numpy()
        expected = np.einsum(einsum_str, A, B)
        print(expected-result_dense)
        assert np.allclose(result_dense, expected), f"Test {i} fehlgeschlagen: {name}"

    # Test 11: Fehlerfall bei inkonsistenten Dimensionen
    print("Test 11: Fehlerfall bei inkonsistenten Dimensionen")
    A = np.random.rand(3, 4).astype(np.float32)
    B = np.random.rand(4, 3).astype(np.float32) # B hat eine inkompatible Form für "ij,ij->ij"
    torch_sparse_A = np_to_torch_sparse(A)
    torch_sparse_B = np_to_torch_sparse(B)
    ssa_path = [(0, 1, "ij,ij->ij")]
    try:
        _ = sparse_einsum_v1(ssa_path, torch_sparse_A, torch_sparse_B)
        assert False, "Test 11 fehlgeschlagen: Fehler bei inkonsistenten Dimensionen nicht ausgelöst"
    except Exception:
        pass  # Fehler ist erwartet

    # Test 12: Batch Matrix-Multiplikation mit gezielt gesetzten Nullen
    print("Test 12: Batch Matrix-Multiplikation")
    A = np.zeros((2, 4, 3), dtype=np.float32)
    A[0, 0, 0] = 1.0
    A[0, 1, 2] = 2.0
    A[1, 2, 2] = 3.0
    
    B = np.zeros((2, 4, 4), dtype=np.float32)
    B[0, 0, 1] = 4.0
    B[0, 2, 3] = 5.0
    B[1, 3, 3] = 6.0
    
    torch_sparse_A = np_to_torch_sparse(A)
    torch_sparse_B = np_to_torch_sparse(B)
    
    einsum_str = "bji,bjk->bik"
    ssa_path = [(0, 1, einsum_str)]
    
    result_sparse, timings = sparse_einsum_v1(ssa_path, torch_sparse_A, torch_sparse_B)
    result_dense = result_sparse.to_dense().numpy()
    
    expected = np.einsum(einsum_str, A, B)
    assert np.allclose(result_dense, expected), "Test 12 fehlgeschlagen: Batch Matrix-Multiplikation"

    print("\nAlle PyTorch SparseTensor Tests bestanden!")


if __name__ == "__main__":
    # Rufen Sie hier die gewünschte Testfunktion auf
    test_myeinsum_torch()