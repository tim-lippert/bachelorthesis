import pandas as pd
import os  # <-- Hinzugefügt

def filter_csv_data(file_path):
    """
    Lädt eine CSV-Datei, filtert sie basierend auf Benutzereingaben für
    'opt_size_avg_density' und 'different_indices' und gibt die
    gefilterten Daten aus.

    Args:
        file_path (str): Der Pfad zur CSV-Datei.
    """
    try:
        # 1. CSV-Datei in ein pandas DataFrame laden
        df = pd.read_csv(file_path)
        print(f"CSV-Datei '{file_path}' wurde erfolgreich geladen.")
        print("-" * 30)

        # 2. Benutzereingaben für die Filterkriterien abfragen
        while True:
            try:
                # Schwellenwert für die durchschnittliche Dichte der optimalen Größe
                density_threshold = float(input("Geben Sie den höchstwert für 'opt_size_avg_density' ein (z.B. 0.5): "))
                break
            except ValueError:
                print("Ungültige Eingabe. Bitte geben Sie eine Zahl ein.")

        # 3. Die Filter auf das DataFrame anwenden
        # Es werden nur Zeilen beibehalten, bei denen BEIDE Bedingungen erfüllt sind
        filtered_df = df[
            (df['opt_size_avg_density'] < density_threshold) & (df["dtype"]=="float64")
        ]

        # 4. Die gefilterten Ergebnisse anzeigen
        print("\n--- Gefilterte Daten ---")
        if filtered_df.empty:
            print("Keine Daten entsprechen Ihren Filterkriterien.")
        else:
            # Zeigt nur die relevanten Spalten und die erste Spalte (filename) an
            display_columns = [
                'filename',
                'tensors',
                'file_size_in_mb',
                'opt_size_avg_density'
            ]
            print(filtered_df[display_columns])

    except FileNotFoundError:
        print(f"Fehler: Die Datei unter dem Pfad '{file_path}' wurde nicht gefunden.")
    except KeyError as e:
        print(f"Fehler: Die Spalte {e} wurde in der CSV-Datei nicht gefunden. Bitte überprüfen Sie die Spaltennamen.")
    except Exception as e:
        print(f"Ein unerwarteter Fehler ist aufgetreten: {e}")

if __name__ == "__main__":
    # --- Korrektur beginnt hier ---
    # Ermittelt das Verzeichnis, in dem das Skript liegt
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Kombiniert den Verzeichnispfad mit dem Dateinamen
    csv_file = os.path.join(script_dir, 'metadata.csv')
    # --- Korrektur endet hier ---
    
    filter_csv_data(csv_file)