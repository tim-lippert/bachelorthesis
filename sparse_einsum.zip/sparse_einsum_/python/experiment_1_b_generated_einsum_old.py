import os
import sys
import time
import contextlib
from typing import Dict, Any, List, Tuple, NamedTuple

import numpy as np
import torch
import matplotlib.pyplot as plt

# Importiere die Wrapper
# Annahme: Diese Dateien existieren im selben Verzeichnis
from wrapper import sparse_einsum_v1 as sparse_einsum_v1  # type: ignore
from wrapper import sparse_einsum_v2 as sparse_einsum_v2  # type: ignore


# ==============================================================================
# Generators (unverändert)
# ==============================================================================

class EinsumExpression(NamedTuple):
    """Kapselt einen Einsum-Ausdruck und die zugehörigen Tensor-Shapes."""
    expression: str
    shape_a: Tuple[int, ...]
    shape_b: Tuple[int, ...]


def generate_einsum_expressions(
    seed: int = 42,
    count: int = 100,
    min_elems: int = 1_000_000,
    max_elems: int = 10_000_000,
    max_out_elems: int = 5_000_000,
) -> List[EinsumExpression]:
    """
    Erzeugt deterministisch 'count' sinnvolle, binäre Einsum-Ausdrücke ohne Ellipsis.
    """
    rng = np.random.RandomState(seed)
    if max_out_elems is None:
        max_out_elems = max_elems

    # Index-Buchstaben (keine Duplikate innerhalb eines Operanden)
    letters = list("abcdefghijklmnopqrstuvwxyz")

    # Dimensionen-Pool so gewählt, dass Produkte gut in [1e6, 1e7] landen,
    # ohne zu häufig gigantische Outputs zu erzeugen.
    dims_pool = np.array([16, 32, 64, 128, 256, 512], dtype=int)
    dim_probs = np.array([0.05, 0.15, 0.30, 0.30, 0.15, 0.05], dtype=float)

    def sample_dim() -> int:
        return int(rng.choice(dims_pool, p=dim_probs))

    def product(xs: Tuple[int, ...] | List[int]) -> int:
        p = 1
        for x in xs:
            p *= int(x)
        return p

    def nearest_allowed_dim(target: int) -> int:
        # Nächste erlaubte Dimension aus dims_pool wählen
        arr = dims_pool
        idx = int(np.argmin(np.abs(arr - target)))
        return int(arr[idx])

    def pick_split(rankA: int, rankB: int) -> Tuple[List[str], List[str], List[str], List[str]]:
        # Wir erzwingen a_only >= 1 und b_only >= 1, damit wir ihre Produkte feinjustieren können.
        # Außerdem mindestens eine kontrahierte Dimension.
        min_shared = 0
        max_contract = min(rankA, rankB) - 1
        if max_contract < 1:
            raise RuntimeError("Unmögliche Ränge für Kontraktion.")
        c_contract = int(rng.randint(1, max_contract + 1))

        max_shared = min(rankA, rankB) - c_contract - 1  # -1 um a_only/b_only >= 1 zu erlauben
        if max_shared < min_shared:
            # Falls das nicht geht, wählen wir kleinere c_contract in einem erneuten Versuch
            return [], [], [], []

        c_shared = int(rng.randint(min_shared, max_shared + 1))
        a_only = rankA - c_shared - c_contract
        b_only = rankB - c_shared - c_contract
        if a_only < 1 or b_only < 1:
            return [], [], [], []

        pool = letters.copy()
        rng.shuffle(pool)
        cursor = 0
        shared = pool[cursor:cursor + c_shared]; cursor += c_shared
        contract = pool[cursor:cursor + c_contract]; cursor += c_contract
        a_only_labels = pool[cursor:cursor + a_only]; cursor += a_only
        b_only_labels = pool[cursor:cursor + b_only]; cursor += b_only
        return shared, contract, a_only_labels, b_only_labels

    def build_one() -> EinsumExpression:
        # Mehrfachversuch, bis alle Nebenbedingungen erfüllt sind
        for _outer in range(2000):
            rankA = int(rng.randint(2, 5))  # 2..4
            rankB = int(rng.randint(2, 5))  # 2..4

            attempt = 0
            while attempt < 50:
                attempt += 1
                shared, contract, a_only_labels, b_only_labels = pick_split(rankA, rankB)
                if not shared and not contract and not a_only_labels and not b_only_labels:
                    continue  # ungültige Aufteilung, nochmal versuchen

                labels_A = shared + contract + a_only_labels
                labels_B = shared + contract + b_only_labels
                rng.shuffle(labels_A)
                rng.shuffle(labels_B)

                out_labels = shared + a_only_labels + b_only_labels
                rng.shuffle(out_labels)
                # Mind. ein Output-Index sicher
                if len(out_labels) == 0:
                    continue

                # Dimensionen für shared/contract frei wählen
                uniq = shared + contract + a_only_labels + b_only_labels
                uniq_set = set(uniq)

                # Dims-Map initialisieren
                dim_map = {}

                # Zuerst shared/contract festlegen
                for l in (shared + contract):
                    dim_map[l] = sample_dim()

                # Jetzt A-only so wählen, dass |A| in [min_elems, max_elems] landet
                baseA = product([dim_map[l] for l in (shared + contract)])
                baseB = baseA

                # A-only
                if len(a_only_labels) >= 1:
                    if len(a_only_labels) >= 2:
                        a_dims = [sample_dim() for l in a_only_labels[:-1]]
                        for l, d in zip(a_only_labels[:-1], a_dims): dim_map[l] = d
                        base_cur = baseA * product(a_dims)
                        targetA = int(rng.randint(min_elems, max_elems + 1))
                        need = max(2, targetA // max(1, base_cur))
                        dim_map[a_only_labels[-1]] = nearest_allowed_dim(need)
                    else:
                        targetA = int(rng.randint(min_elems, max_elems + 1))
                        need = max(2, targetA // max(1, baseA))
                        dim_map[a_only_labels[0]] = nearest_allowed_dim(need)
                else:
                    continue

                # B-only
                if len(b_only_labels) >= 1:
                    if len(b_only_labels) >= 2:
                        b_dims = [sample_dim() for l in b_only_labels[:-1]]
                        for l, d in zip(b_only_labels[:-1], b_dims): dim_map[l] = d
                        base_cur = baseB * product(b_dims)
                        targetB = int(rng.randint(min_elems, max_elems + 1))
                        need = max(2, targetB // max(1, base_cur))
                        dim_map[b_only_labels[-1]] = nearest_allowed_dim(need)
                    else:
                        targetB = int(rng.randint(min_elems, max_elems + 1))
                        need = max(2, targetB // max(1, baseB))
                        dim_map[b_only_labels[0]] = nearest_allowed_dim(need)
                else:
                    continue

                shape_a = tuple(dim_map[l] for l in labels_A)
                shape_b = tuple(dim_map[l] for l in labels_B)

                if not (min_elems <= product(shape_a) <= max_elems and min_elems <= product(shape_b) <= max_elems):
                    continue

                out_shape = tuple(dim_map[l] for l in out_labels)
                if product(out_shape) > max_out_elems:
                    continue

                expr = f"{''.join(labels_A)},{''.join(labels_B)}->{''.join(out_labels)}"
                return EinsumExpression(expr, shape_a, shape_b)

        raise RuntimeError("Konnte keinen gültigen Ausdruck finden.")

    expressions: List[EinsumExpression] = [
        EinsumExpression("bji,bjk->bik", (64, 256, 256), (64, 256, 256)),
        EinsumExpression("btij,btjk->btik", (8, 8, 256, 128), (8, 8, 128, 256)),
        EinsumExpression("bij,bci->bcj", (64, 256, 64), (64, 128, 256)),
        EinsumExpression("ab,bc->ac", (1024, 1024), (1024, 1024)),
    ]

    def in_range(e: EinsumExpression) -> bool:
        a = int(np.prod(e.shape_a)); b = int(np.prod(e.shape_b))
        out_labels = e.expression.split("->")[1]
        la, lb = e.expression.split("->")[0].split(",")
        dim_map = {l: d for l, d in zip(la, e.shape_a)}
        dim_map.update({l: d for l, d in zip(lb, e.shape_b) if l not in dim_map})
        out_shape = tuple(dim_map[l] for l in out_labels)
        outn = int(np.prod(out_shape))
        return (min_elems <= a <= max_elems) and (min_elems <= b <= max_elems) and (outn <= max_out_elems)

    expressions = [e for e in expressions if in_range(e)]
    seen = {e.expression for e in expressions}

    guard = 0
    while len(expressions) < count and guard < count * 200:
        guard += 1
        try:
            e = build_one()
            if e.expression not in seen:
                seen.add(e.expression)
                expressions.append(e)
        except RuntimeError:
            pass

    if len(expressions) < count:
        print(f"Warnung: Nur {len(expressions)} Ausdrücke gefunden.")

    rng.shuffle(expressions)
    return expressions


def make_random_sparse_tensors(
    shape_a: Tuple[int, ...], shape_b: Tuple[int, ...], density: float
) -> Tuple[np.ndarray, np.ndarray]:
    A_np = (np.random.rand(*shape_a).astype(np.float32))
    B_np = (np.random.rand(*shape_b).astype(np.float32))
    if density < 1.0:
        A_np *= (np.random.rand(*shape_a) < density)
        B_np *= (np.random.rand(*shape_b) < density)
    return A_np, B_np


# ==============================================================================
# Helpers
# ==============================================================================

def set_reproducible(seed: int = 42):
    np.random.seed(seed)
    torch.manual_seed(seed)
    np.random.RandomState(seed)

def np_to_torch_sparse(np_array: np.ndarray) -> torch.Tensor:
    non_zero_indices = np.nonzero(np_array)
    if len(non_zero_indices[0]) == 0:
        indices = torch.empty((np_array.ndim, 0), dtype=torch.long)
        values = torch.empty((0,), dtype=torch.float32)
    else:
        indices = torch.tensor(np.array(non_zero_indices), dtype=torch.long)
        values = torch.tensor(np_array[non_zero_indices], dtype=torch.float32)
    return torch.sparse_coo_tensor(indices, values, np_array.shape).coalesce()

def density_schedule(start: float, steps: int, cap: float = 1.0) -> List[float]:
    ds = []
    d = start
    for _ in range(steps):
        ds.append(min(d, cap))
        if d >= cap: break
        d *= 2.0
    return ds


# ==============================================================================
# Timing Functions
# ==============================================================================

def time_torch_einsum_runs(expression: str, A_dense: torch.Tensor, B_dense: torch.Tensor, num_runs: int) -> List[float]:
    times = []
    result = []
    with torch.no_grad():
        for _ in range(2): torch.einsum(expression, A_dense, B_dense)
        for _ in range(num_runs):
            t0 = time.perf_counter(); result = torch.einsum(expression, A_dense, B_dense); t1 = time.perf_counter()
            times.append(t1 - t0)
    print("Torch sum: ", torch.sum(result))
    return times

def time_my_sparse_einsum_runs(ssa_path: List[Tuple[int, int, str]], A_sparse: torch.Tensor, B_sparse: torch.Tensor, num_runs: int) -> List[float]:
    times = []
    result = []
    for _ in range(2): sparse_einsum_v1(ssa_path, A_sparse, B_sparse)
    for _ in range(num_runs):
        t0 = time.perf_counter(); 
        result = sparse_einsum_v1(ssa_path, A_sparse, B_sparse); 
        t1 = time.perf_counter()
        times.append(t1 - t0)
    print("v1 sum: ", torch.sum(result[0]))
    return times

def time_my_sparse_einsum_v2_runs(ssa_path: List[Tuple[int, int, str]], A_sparse: torch.Tensor, B_sparse: torch.Tensor, num_runs: int) -> List[float]:
    times = []
    result = []
    for _ in range(2): sparse_einsum_v2(ssa_path, A_sparse, B_sparse)
    for _ in range(num_runs):
        t0 = time.perf_counter(); 
        result = sparse_einsum_v2(ssa_path, A_sparse, B_sparse); 
        t1 = time.perf_counter()
        times.append(t1 - t0)
    print("v2 sum: ", torch.sum(result[0]))
    return times


# ==============================================================================
# Benchmarking
# ==============================================================================

def run_aggregated_benchmark(
    expressions: List[EinsumExpression],
    densities: List[float],
    runs_per_expression: int = 3,
) -> Dict[str, List[float]]:
    """
    Führt den Benchmark über alle Ausdrücke und Dichten durch und aggregiert die Ergebnisse.
    Zusätzlich: Speedup wird pro Expression berechnet (speedup_i = torch_i / my_i) und
    danach über alle Expressions gemittelt.
    """
    densities_done: List[float] = []
    avg_torch_per_density: List[float] = []
    avg_my_v1_per_density: List[float] = []
    avg_my_v2_per_density: List[float] = []

    # Neu: gemittelte Speedups pro Dichte (Mittel der per-Expression-Speedups)
    avg_my_v1_speedup_per_density: List[float] = []
    avg_my_v2_speedup_per_density: List[float] = []

    # Flags (deaktivieren ggf. Messungen; aktuell bleiben sie True wie bei dir)
    benchmark_v1 = True
    benchmark_v2 = True

    num_expr = len(expressions)
    print(f"Starte aggregierten Benchmark für {num_expr} Einsum-Ausdrücke.")
    print(f"Dichten: {[f'{d:.1e}' for d in densities]}")

    for density in densities:
        if not benchmark_v1 and not benchmark_v2:
            print("-> Alle Sparse-Implementierungen sind langsamer. Breche Benchmark ab.")
            break

        all_torch_times: List[float] = []
        all_my_times_v1: List[float] = []
        all_my_times_v2: List[float] = []

        # Neu: Speedups pro Expression sammeln
        v1_speedups_expr: List[float] = []
        v2_speedups_expr: List[float] = []

        for i, expr in enumerate(expressions):
            print(f"\r  Density {density:.1e}: Processing expression {i+1}/{num_expr}...", end="")

            ssa_path = [(0, 1, expr.expression)]
            A_np, B_np = make_random_sparse_tensors(expr.shape_a, expr.shape_b, density)

            A_dense, B_dense = torch.from_numpy(A_np), torch.from_numpy(B_np)
            A_sparse, B_sparse = np_to_torch_sparse(A_np), np_to_torch_sparse(B_np)

            # torch.einsum Zeit
            torch_time = float(np.mean(time_torch_einsum_runs(expr.expression, A_dense, B_dense, runs_per_expression)))
            all_torch_times.append(torch_time)

            # v1
            if benchmark_v1:
                my_time_v1 = float(np.mean(time_my_sparse_einsum_runs(ssa_path, A_sparse, B_sparse, runs_per_expression)))
                all_my_times_v1.append(my_time_v1)
                if my_time_v1 > 0 and np.isfinite(my_time_v1) and np.isfinite(torch_time):
                    v1_speedups_expr.append(torch_time / my_time_v1)

            # v2
            if benchmark_v2:
                my_time_v2 = float(np.mean(time_my_sparse_einsum_v2_runs(ssa_path, A_sparse, B_sparse, runs_per_expression)))
                all_my_times_v2.append(my_time_v2)
                if my_time_v2 > 0 and np.isfinite(my_time_v2) and np.isfinite(torch_time):
                    v2_speedups_expr.append(torch_time / my_time_v2)

        print()

        # Mittelwerte der Zeiten (wie bisher)
        avg_torch = float(np.mean(all_torch_times)) if all_torch_times else np.nan
        avg_v1 = float(np.mean(all_my_times_v1)) if (benchmark_v1 and all_my_times_v1) else np.nan
        avg_v2 = float(np.mean(all_my_times_v2)) if (benchmark_v2 and all_my_times_v2) else np.nan

        # Neu: Mittel der per-Expression-Speedups
        v1_speedup_avg = float(np.mean(v1_speedups_expr)) if v1_speedups_expr else np.nan
        v2_speedup_avg = float(np.mean(v2_speedups_expr)) if v2_speedups_expr else np.nan

        # Sammeln
        densities_done.append(density)
        avg_torch_per_density.append(avg_torch)
        avg_my_v1_per_density.append(avg_v1)
        avg_my_v2_per_density.append(avg_v2)
        avg_my_v1_speedup_per_density.append(v1_speedup_avg)
        avg_my_v2_speedup_per_density.append(v2_speedup_avg)

        # Log-Ausgabe inkl. Speedups (per-Expression gemittelt)
        log_msg = f"  -> Avg Times (ms): torch={avg_torch*1e3:.3f}"
        if benchmark_v1:
            log_msg += f", v1={avg_v1*1e3:.3f}"
            if np.isfinite(v1_speedup_avg):
                log_msg += f" | Speedup v1=x{v1_speedup_avg:.2f}"
        if benchmark_v2:
            log_msg += f", v2={avg_v2*1e3:.3f}"
            if np.isfinite(v2_speedup_avg):
                log_msg += f" | Speedup v2=x{v2_speedup_avg:.2f}"
        print(log_msg)


    return {
        "densities": densities_done,
        "avg_torch_times": avg_torch_per_density,
        "avg_my_times_v1": avg_my_v1_per_density,
        "avg_my_times_v2": avg_my_v2_per_density,
        "avg_my_v1_speedup_per_density": avg_my_v1_speedup_per_density,
        "avg_my_v2_speedup_per_density": avg_my_v2_speedup_per_density,
    }


# ==============================================================================
# Main Execution
# ==============================================================================

def main():
    set_reproducible(123)
    torch.set_grad_enabled(False)

    # Konfiguration
    num_expressions_to_gen = 50
    runs_per_expression = 3
    start_density = 0.0128
    density_steps = 10

    expressions = generate_einsum_expressions(seed=42, count=num_expressions_to_gen)
    densities = density_schedule(start=start_density, steps=density_steps, cap = 0.0512)

    results = run_aggregated_benchmark(
        expressions=expressions,
        densities=densities,
        runs_per_expression=runs_per_expression,
    )

    print("\nBenchmark abgeschlossen.")


if __name__ == "__main__":
    main()