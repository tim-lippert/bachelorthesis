import os
import sys
import time
from dataclasses import dataclass
from typing import List, Tuple, Any, Dict, Callable

# Setzen der Umgebungsvariable, um lokale Daten zu verwenden
data_dir = "/root/einsum_data"
if 'EINSUM_BENCHMARK_DATA_DIR' not in os.environ and os.path.exists(data_dir):
    os.environ['EINSUM_BENCHMARK_DATA_DIR'] = data_dir

import numpy as np
import torch
import einsum_benchmark
from einsum_benchmark.meta import to_annotated_ssa_path, to_ssa_path

import sparse
import opt_einsum as oe

from wrapper import sparse_einsum_v1, sparse_einsum_v2, sanitize_subscripts



# ==============================================================================
# 1. DATENVORBEREITUNG MIT CACHING
# ==============================================================================
@dataclass
class EinsumInstance:
    format_string: str
    tensors: List[np.ndarray]
    path: List[Tuple[Any, ...]]
    ssa_path: List[Tuple[Any, ...]]
    key: str

def get_predefined_instances(instance_keys: List[str], cache_file: str = "path_cache.json") -> List[EinsumInstance]:
    """
    Lädt vordefinierte Instanzen und verwendet einen lokalen Cache für die teure Pfadfindung.
    """

    prepared_instances: List[EinsumInstance] = []

    print(f"Bereite {len(instance_keys)} Instanzen vor...")
    for key in instance_keys:
        path = None
        annotated_ssa_path = None
        
        instance_data = einsum_benchmark.instances[key]
        if instance_data.paths and instance_data.paths.opt_size: 
            path = instance_data.paths.opt_size.path
            annotated_ssa_path = to_annotated_ssa_path(instance_data.format_string, to_ssa_path(path))
        else:
            print("Fehler: kein Pfad zur zugehörigen Instanz gefunden")
            sys.exit(1)

        try:
            instance_data = einsum_benchmark.instances[key]
            prepared_instances.append(EinsumInstance(
                format_string=instance_data.format_string,
                ssa_path=annotated_ssa_path,
                tensors=instance_data.tensors,
                path=path,
                key=key,
            ))
        except Exception as e:
            print(f"    -> Fehler beim Laden der Instanzdaten für '{key}': {e}. Wird übersprungen.")
            continue

    return prepared_instances

# ==============================================================================
# 2. HILFSFUNKTIONEN
# ==============================================================================
def set_reproducible(seed: int = 42):
    np.random.seed(seed)
    torch.manual_seed(seed)

def np_to_torch_sparse(np_array: np.ndarray) -> torch.Tensor:
    np_array = np_array.astype(np.float32)
    non_zero_indices = np.nonzero(np_array)
    indices = torch.tensor(np.array(non_zero_indices), dtype=torch.long)
    values = torch.tensor(np_array[non_zero_indices], dtype=torch.float64)
    return torch.sparse_coo_tensor(indices, values, np_array.shape).coalesce()

def np_to_sparse_coo(np_array: np.ndarray) -> sparse.COO:
    """Konvertiert ein NumPy-Array in ein sparse.COO-Array."""
    return sparse.COO.from_numpy(np_array.astype(np.float64))

# ==============================================================================
# 3. BENCHMARK-AUSFÜHRUNGSFUNKTIONEN
# ==============================================================================

def execute_sparse_einsum_pairwise(
    *operands: sparse.COO,
    ssa_path: List[Tuple[Any, ...]] = None,
):  
    n = len(operands)
    store: Dict[int, sparse.COO] = {i: t for i, t in enumerate(operands)}
    last_id = None

    for step_idx, (i_id, j_id, fmt) in enumerate(ssa_path):
        a, b = store[i_id], store[j_id]
        res = oe.contract(sanitize_subscripts(fmt),a,b, backend="sparse")
        out_id = n + step_idx
        store[out_id] = res
        last_id = out_id

    if last_id is None:
        raise RuntimeError("SSA-Pfad war leer – kein Ergebnis erzeugt.")
    return store[last_id]
    

def time_measurement_loop(func: Callable, num_runs: int, warmup_runs: int) -> float:
    with torch.no_grad():
        for _ in range(warmup_runs):
            func()
        times = []
        for _ in range(num_runs):
            start_time = time.perf_counter()
            result = func()
            end_time = time.perf_counter()
            times.append(end_time - start_time)
    print("Ergebnis: ", torch.sum(result[0]) if type(result) == tuple else torch.sum(result) if type(result)==torch.Tensor else result.sum())
    return float(np.mean(times))

# ==============================================================================
# 4. BENCHMARK-DURCHFÜHRUNG
# ==============================================================================
def run_benchmark(
    instances: List[EinsumInstance], 
    torch_successful_instances: List[str],
    num_runs: int = 5, 
    warmup_runs: int = 1
) -> Dict[str, Any]:
    results: Dict[str, Any] = {
        "instance_keys": [], 
        "torch_einsum_times": [],
        "sparse_lib_times_regular": [],
        "sparse_lib_times_optimized": [], 
        "my_v1_times": [], 
        "my_v2_times": []
    }
    
    print(f"\nStarte Benchmark für {len(instances)} Instanzen...")
    for i, instance in enumerate(instances):
        print(f"  [{i+1}/{len(instances)}] Messe Laufzeit für: {instance.key}")
        
        
        # --- torch.einsum Messung (nur für erfolgreiche Instanzen) ---
        torch_time: Any = "TIMEOUT"
        if instance.key in torch_successful_instances:
            print("  Messe `torch.einsum`...")
            tensors_torch_dense = [torch.from_numpy(t.astype(np.float64)) for t in instance.tensors]
            torch_time = time_measurement_loop(
                lambda: oe.contract(instance.format_string,*tensors_torch_dense, optimize=instance.path, backend="torch"),
                num_runs=num_runs, warmup_runs=warmup_runs
            )
        else:
            print("  Überspringe `torch.einsum` (als TIMEOUT markiert).")
        
        # --- Bestehende Messungen ---
        tensors_sparse_lib = [np_to_sparse_coo(t) for t in instance.tensors]
        tensors_torch_sparse = [np_to_torch_sparse(t) for t in instance.tensors]
        
        
        print("  Messe `sparse.einsum` paarweise...")
        sparse_lib_time_optimized = time_measurement_loop(
            lambda: execute_sparse_einsum_pairwise(*tensors_sparse_lib, ssa_path=instance.ssa_path),
            num_runs=num_runs, warmup_runs=warmup_runs
        )
        
        
        print("  Messe `sparse_einsum` (v1)...")
        my_v1_time = time_measurement_loop(
            lambda: sparse_einsum_v1(instance.ssa_path, *tensors_torch_sparse),
            num_runs=num_runs, warmup_runs=warmup_runs
        )
        
        print("  Messe `sparse_einsum` (v2)...")
        my_v2_time = time_measurement_loop(
            lambda: sparse_einsum_v2(instance.ssa_path, *tensors_torch_sparse),
            num_runs=num_runs, warmup_runs=warmup_runs
        )
        
        results["instance_keys"].append(instance.key)
        results["torch_einsum_times"].append(torch_time)
        results["sparse_lib_times_optimized"].append(sparse_lib_time_optimized)
        results["my_v1_times"].append(my_v1_time)
        results["my_v2_times"].append(my_v2_time)
        
        torch_time_str = f"{torch_time*1e3:.3f}" if isinstance(torch_time, float) else torch_time
        print(f"    -> Zeiten (ms): torch.einsum={torch_time_str}, sparse.einsum (optimized) ={sparse_lib_time_optimized*1e3:.3f}, v1={my_v1_time*1e3:.3f}, v2={my_v2_time*1e3:.3f}")
        
    return results

# ==============================================================================
# 6. MAIN-FUNKTION (MODIFIZIERT)
# ==============================================================================
def main():
    set_reproducible(123)
    torch.set_grad_enabled(False)
    
    # Instanzen
    PREDEFINED_INSTANCE_KEYS = ["mc_2022_087", "mc_2021_036", "mc_2022_025", 
                                "wmc_2022_038", "wmc_2023_036", "mc_rw_log-1", 
                                "wmc_2021_145"]
   
    # Instanzen, die für torch.einsum erfolgreich getestet wurden
    TORCH_SUCCESSFUL_INSTANCES = [
        "mc_2022_087", 'mc_2022_025', 'wmc_2022_038', "wmc_2023_036"
    ]

    RUNS_PER_INSTANCE, WARMUP_RUNS = 5, 1
    
    instances_to_benchmark = get_predefined_instances(PREDEFINED_INSTANCE_KEYS, cache_file="path_cache.json")
    
    if not instances_to_benchmark:
        print("\nKeine Instanzen konnten geladen werden. Benchmark wird abgebrochen.")
        return
        
    results = run_benchmark(
        instances=instances_to_benchmark, 
        torch_successful_instances=TORCH_SUCCESSFUL_INSTANCES,
        num_runs=RUNS_PER_INSTANCE, 
        warmup_runs=WARMUP_RUNS
    )
    
    print("\nBenchmark abgeschlossen.")
    print("--- Ergebnisse ---")
    # Formatierte Ausgabe für bessere Lesbarkeit
    for i, key in enumerate(results["instance_keys"]):
        torch_t = results["torch_einsum_times"][i]
        torch_t_str = f"{torch_t:.4f}s" if isinstance(torch_t, float) else torch_t
        
        print(f"Instanz: {key}")
        print(f"  - torch.einsum:            {torch_t_str}")
        print(f"  - sparse.einsum (optimized): {results['sparse_lib_times_optimized'][i]:.4f}s")
        print(f"  - sparse_einsum_v1:        {results['my_v1_times'][i]:.4f}s")
        print(f"  - sparse_einsum_v2:        {results['my_v2_times'][i]:.4f}s")
        print("-" * 20)


if __name__ == "__main__":
    main()