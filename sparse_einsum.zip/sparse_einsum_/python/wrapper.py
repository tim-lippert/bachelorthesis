import sys
import os
from torch import sparse_coo_tensor
import string

#Füge den build-Pfad zum Python-Suchpfad hinzu
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "build"))

import myeinsum #type:ignore

def sanitize_subscripts(fmt: str) -> str:
    """
    Konvertiert einen 'einsum'-Formatstring mit beliebigen Unicode-Zeichen
    in einen äquivalenten String, der nur ASCII-Buchstaben (a-zA-Z) verwendet.

    Die Funktion stellt sicher, dass jedes einzigartige Unicode-Zeichen konsistent
    auf ein einzigartiges ASCII-Zeichen abgebildet wird. Die Struktur des
    Strings (z.B. 'in1,in2->out') bleibt erhalten.

    Args:
        fmt: Der ursprüngliche Formatstring, z.B. 'Ǭǫ,ɂƃ->Ǭǫɂƃ'.

    Returns:
        Ein neuer Formatstring, der nur ASCII-Buchstaben und die
        Trennzeichen ',' und '->' enthält, z.B. 'ab,cd->abcd'.
    
    Raises:
        ValueError: Wenn mehr als 52 einzigartige Zeichen im Eingabe-String
                    vorhanden sind, da der Zielzeichensatz (a-zA-Z)
                    erschöpft ist.
    """
    # 1. Definiere den Pool an "sicheren" Zeichen, die wir verwenden wollen.
    #    string.ascii_letters ist 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    safe_chars = string.ascii_letters
    
    # 2. Erstelle eine leere Übersetzungstabelle (mapping) und einen Zähler
    #    für die verfügbaren sicheren Zeichen.
    char_map = {}
    safe_char_iterator = iter(safe_chars)
    
    # 3. Baue den neuen, bereinigten String.
    sanitized_list = []
    for char in fmt:
        # Behalte die Strukturzeichen von einsum bei.
        if char in (',', '-', '>'):
            sanitized_list.append(char)
            continue
            
        # Wenn das Zeichen bereits übersetzt wurde, verwende die bekannte Übersetzung.
        if char in char_map:
            sanitized_list.append(char_map[char])
        else:
            # Andernfalls, nimm das nächste verfügbare "sichere" Zeichen.
            try:
                new_char = next(safe_char_iterator)
                char_map[char] = new_char
                sanitized_list.append(new_char)
            except StopIteration:
                # Dieser Fall tritt ein, wenn alle 52 sicheren Zeichen verbraucht sind.
                raise ValueError(
                    f"Zu viele einzigartige Symbole im String (mehr als {len(safe_chars)}). "
                    "Der sichere Zeichensatz ist erschöpft."
                )
    return "".join(sanitized_list) 

def sparse_einsum_v1(ssa_path, *arguments):
    sanitized_ssa_path = [(i[0],i[1],sanitize_subscripts(i[2])) for i in ssa_path]
    timings, (values, coords, shape) = myeinsum.einsum(sanitized_ssa_path, *arguments)
    sparse_array = sparse_coo_tensor(indices=coords, values = values, size =shape)
    return sparse_array, timings

def sparse_einsum_v2(ssa_path, *arguments):
    sanitized_ssa_path = [(i[0],i[1],sanitize_subscripts(i[2])) for i in ssa_path]
    timings, (values, coords, shape) = myeinsum.einsum_v2(sanitized_ssa_path, *arguments)
    sparse_array = sparse_coo_tensor(indices=coords, values = values, size =shape)
    return (sparse_array, timings)


