import matplotlib.pyplot as plt
import numpy as np

# Daten aus der Tabelle
densities = ["0.0001", "0.0002", "0.0004", "0.0008", "0.0016", "0.0032", "0.0064"]
steps = [
    "Clear Repeated Indices",
    "Eliminate Summed Indices",
    "Transpose (pre-BMM)",
    "Sort (pre-BMM)",
    "Reshape (pre-BMM)",
    "BMM",
    "Reshape (post-BMM)",
    "Transpose (final)",
    "Rest"
]

# Schrittzeiten für v1 und v2 pro Dichte
step_values_v1 = np.array([
    [0.060, 0.109, 0.272, 0.786, 1.069, 1.893, 3.739],
    [0.059, 0.107, 0.252, 0.924, 1.129, 1.933, 3.649],
    [1.265, 2.331, 4.141, 8.979, 19.661, 28.302, 53.931],
    [0.531, 0.828, 1.329, 2.609, 6.177, 9.706, 18.254],
    [1.908, 3.613, 6.716, 14.177, 25.888, 44.006, 81.060],
    [1.536, 3.341, 7.735, 26.557, 154.103, 611.459, 2739.683],
    [0.101, 0.209, 0.822, 2.777, 12.758, 43.257, 128.851],
    [0.042, 0.143, 0.484, 1.763, 10.272, 25.739, 74.133],
    [1.434, 2.333, 4.836, 12.606, 45.168, 96.586, 377.276]
])
step_values_v2 = np.array([
    [0.052, 0.114, 0.264, 0.563, 0.969, 1.923, 3.671],
    [0.052, 0.104, 0.246, 1.191, 0.942, 1.938, 3.674],
    [1.182, 2.512, 4.267, 10.383, 18.105, 28.542, 55.701],
    [0.403, 0.885, 1.353, 3.568, 4.793, 9.578, 18.761],
    [1.819, 3.876, 7.188, 14.072, 24.658, 48.138, 83.296],
    [8.237, 32.116, 110.288, 378.269, 1095.004, 2943.816, 6510.825],
    [0.073, 0.237, 0.776, 3.019, 10.329, 38.386, 151.081],
    [0.043, 0.174, 0.509, 2.001, 9.147, 26.688, 150.127],
    [1.381, 2.586, 5.098, 15.006, 39.693, 91.255, 375.029]
])

# Gesamtzeiten pro Dichte (aus Tabelle, letzte Zeile)
ges_v1 = np.array([6.935, 13.014, 26.586, 71.177, 276.226, 862.881, 3480.577])
ges_v2 = np.array([13.242, 42.604, 129.989, 428.071, 1203.639, 3190.264, 7352.165])

# Schrittanteile berechnen (jeder Wert durch die Gesamtdauer)
rel_values_v1 = step_values_v1 / ges_v1
rel_values_v2 = step_values_v2 / ges_v2

# Farben für die einzelnen Schritte
cmap = plt.get_cmap("tab20")
colors = [cmap(i) for i in range(len(steps))]

x = np.arange(len(densities))
bar_width = 0.35

# Plot ohne Legende
fig, ax = plt.subplots(figsize=(14, 8))
# Wenn wir die Segmente in umgekehrter Reihenfolge zeichnen (letzter Schritt zuerst),
# dann liegt der erste Schritt (steps[0]) am Ende oben — so stimmt die Stapelreihenfolge
# mit der Reihenfolge der Legende.
bottom_v1 = np.zeros(len(densities))
bottom_v2 = np.zeros(len(densities))
bars_v1 = []
bars_v2 = []

# Zeichne vom letzten Schritt zum ersten, sodass steps[0] oben liegt
for i in range(len(steps) - 1, -1, -1):
    bars_v1.append(
        ax.bar(x - bar_width/2, rel_values_v1[i], bar_width, bottom=bottom_v1, color=colors[i],
               edgecolor="black", linewidth=0.7)
    )
    bars_v2.append(
        ax.bar(x + bar_width/2, rel_values_v2[i], bar_width, bottom=bottom_v2, color=colors[i],
               edgecolor="black", linewidth=0.7)
    )
    bottom_v1 += rel_values_v1[i]
    bottom_v2 += rel_values_v2[i]

ax.set_ylim(0, 1)
ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
ax.set_yticklabels(["0%", "25%", "50%", "75%", "100%"], fontsize=16)
ax.set_xticks(x)
ax.set_xticklabels(densities, fontsize=16)
ax.set_xlabel("Dichte", fontsize=20, labelpad=12)
ax.set_ylabel("Relativer Anteil an Gesamtdauer", fontsize=20, labelpad=12)
plt.tight_layout()
plt.savefig("1_a_steps_plot.png")

# Legende separat als Plot speichern (unverändert)
fig_leg, ax_leg = plt.subplots(figsize=(2.6, 2.6))
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[i], edgecolor="black", linewidth=0.7) for i in range(len(steps))]
legend = ax_leg.legend(handles, steps, title="Schritt", loc="center", frameon=False)
ax_leg.axis("off")
fig_leg.tight_layout()
plt.savefig("1_a_steps_legend.png")