#ifndef EINSUM_H
#define EINSUM_H

#include <vector>
#include <string>
#include <stdexcept>
#include <iostream>
#include <cassert>
#include <algorithm>

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>


using uint128_t = unsigned __int128;
using TimingsList = std::vector<std::pair<std::string, double>>; //Definition für die Liste der Zeitmessungen
namespace py = pybind11;
//Optimierte Struktur für einen Sparse-Tensor
struct SparseTensor {
    //Anzahl der Dimensionen des Tensors
    int ndim;
    
    //Shape des Tensors
    std::vector<ssize_t> shape;
    
    //Gepackte Koordinaten. Jedes Element ist ein 128-Bit-Integer, der die vollständigen Koordinaten eines Nicht-Null-Elements kodiert.
    std::vector<uint128_t> packed_coords;
    
    //Werte der Nicht-Null-Elemente
    std::vector<double> values;
    
    //Hilfsvektor zur Speicherung der Anzahl der Bits, die für jede Koordinate benötigt werden, wird für das Packen und Entpacken benötigt.
    std::vector<int> bits_per_dim;

    //Konstruktor
    SparseTensor(const std::vector<ssize_t>& tensor_shape) 
        : ndim(tensor_shape.size()), shape(tensor_shape) {
        
        //Berechne die Anzahl der Bits, die für jede Dimension benötigt werden.
        bits_per_dim.resize(ndim);
        int total_bits = 0;
        for (int i = 0; i < ndim; ++i) {
            //Finde die Anzahl der Bits, die benötigt werden.
            //__builtin_clzll zählt führende Nullen für 64-Bit-ssize_t.
            //Wir ziehen 1 von der Shape ab, da Koordinaten bei n Werte zwischen 0 und n-1 annehmen
            if (shape[i] <= 1) {
                bits_per_dim[i] = 1; //Mindestens 1 Bit, um 0 darzustellen
            } else {
                bits_per_dim[i] = 64 - __builtin_clzll(shape[i] - 1);
            }
            total_bits += bits_per_dim[i];
        }

        //Überprüfe, ob die Gesamtanzahl der Bits in einen 128-Bit-Integer passt.
        if (total_bits > 128) {
            throw std::runtime_error("Die Gesamtanzahl der Bits für die Koordinaten übersteigt 128. Shape ist zu groß zum Packen.");
        }
    }
    
    //Anzahl der Nicht-Null-Elemente
    int nnz() const { 
        return values.size(); 
    }

    //Packt einen Vektor von Koordinaten in einen einzigen uint128_t-Wert.
    uint128_t pack_coords(const std::vector<int>& coord_vec) const {
        assert(coord_vec.size() == ndim && "Koordinatenvektor hat die falsche Dimension.");
        
        uint128_t packed = 0;
        int current_bit_offset = 0;
        for (int i = 0; i < ndim; ++i) {
            //Verschiebe die gerade gepackten Bits nach links, um Platz für die neue Koordinate zu schaffen.
            packed <<= bits_per_dim[i];
            //Füge die neue Koordinate hinzu.
            packed |= static_cast<uint128_t>(coord_vec[i]);
        }
        return packed;
    }

    //Entpackt einen uint128_t-Wert zurück in einen Vektor von Koordinaten.
    void unpack_coords(uint128_t packed, std::vector<int>& result_vec) const {
        assert(result_vec.size() == ndim && "Ergebnisvektor hat die falsche Dimension.");
        
        uint128_t temp_packed = packed;
        
        //Entpacke die Koordinaten von der letzten zur ersten Dimension da sie so gepackt wurden.
        for (int i = ndim - 1; i >= 0; --i) {
            //Erstelle eine Maske, um die Bits dieser Dimension zu extrahieren.
            uint128_t mask = (static_cast<uint128_t>(1) << bits_per_dim[i]) - 1;

            //Füge Wert Ergebnisvektor hinzu
            result_vec[i] = static_cast<int>(temp_packed & mask);
            
            //Verschiebe die gepackten Bits nach rechts, um die nächste Koordinate zu lesen.
            temp_packed >>= bits_per_dim[i];
        }
    }

    // Fügt ein neues Nicht-Null-Element hinzu, indem es die Koordinaten packt.
    void add_element(const std::vector<int>& coord_vec, double value) {
        packed_coords.push_back(pack_coords(coord_vec));
        values.push_back(value);
    }
};


//Deklaration weiterer Funktionen
py::tuple sparse_tensor_to_coo_components(const SparseTensor& tensor);
SparseTensor torch_sparse_to_sparse_tensor(py::handle torch_sparse);

std::pair<SparseTensor, TimingsList> perform_einsum(
    const std::string& op_name,
    const SparseTensor& tensor_a,
    const SparseTensor& tensor_b);

std::pair<SparseTensor, TimingsList> perform_einsum_v2(
    const std::string& op_name,
    const SparseTensor& tensor_a,
    const SparseTensor& tensor_b);

#endif