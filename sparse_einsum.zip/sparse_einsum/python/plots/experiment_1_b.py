import matplotlib.pyplot as plt
import numpy as np

# Neue Daten aus Experiment
densities = np.array([1.0e-4, 2.0e-4, 4.0e-4, 8.0e-4, 1.6e-3, 3.2e-3, 6.4e-3, 1.28e-2])
einsum = np.array([0.001674, 0.002179, 0.002265, 0.001651, 0.002098, 0.001823, 0.001758, 0.001931])
v1 = np.array([0.000422, 0.000454, 0.000423, 0.000438, 0.000820, 0.000641, 0.000916, 0.001760])
v2 = np.array([0.000374, 0.000523, 0.000510, 0.000575, 0.000986, 0.000757, 0.001205, 0.002089])
speedup_v1 = np.array([4.409577, 4.885989, 5.186012, 3.970511, 3.085893, 3.009986, 2.200789, 1.260393])
speedup_v2 = np.array([4.582367, 4.515750, 4.696303, 3.164140, 2.589044, 2.730653, 1.796527, 1.184269])

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10,10), sharex=True)

# Laufzeiten plotten
ax1.plot(densities, einsum*1000, marker='o', label='torch.einsum', color='tab:blue')  # ms
ax1.plot(densities, v1*1000, marker='s', label='v1', color='tab:orange')  # ms
ax1.plot(densities, v2*1000, marker='^', label='v2', color='tab:green')  # ms

ax1.set_ylabel('Laufzeit (ms)', fontsize=14)
ax1.set_title('Laufzeiten', fontsize=16)
ax1.legend()
ax1.grid(True, which="major", ls="--", lw=0.5)

# Speedup plotten
ax2.plot(densities, speedup_v1, marker='s', label='v1', color='tab:orange')
ax2.plot(densities, speedup_v2, marker='^', label='v2', color='tab:green')
ax2.axhline(1, color='grey', ls=':', lw=1)
ax2.set_xscale('log')
ax2.set_xlabel('Dichte', fontsize=14)
ax2.set_ylabel('Speedup', fontsize=14)
ax2.set_title('Durchschnitts-Speedup vs. torch.einsum', fontsize=16)
ax2.legend()
ax2.grid(True, which="major", ls="--", lw=0.5)

plt.tight_layout()
plt.savefig("aggregated_einsum_runtimes_new.png")