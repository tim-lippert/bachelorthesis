import matplotlib.pyplot as plt
import numpy as np

# Daten aus der neuen Tabelle (torch.bmm statt torch.einsum)
densities = np.array([0.0001, 0.0002, 0.0004, 0.0008, 0.0016, 0.0032, 0.0064])
bmm = np.array([1069.568, 1059.073, 983.326, 1009.844, 1088.924, 1008.401, 989.859])
v1 = np.array([6.935, 13.014, 26.586, 71.177, 276.226, 862.881, 3480.577])
v2 = np.array([13.242, 42.604, 129.989, 428.071, 1203.639, 3190.264, 7352.165])
speedup_v1 = np.array([162.245, 84.129, 38.981, 14.982, 4.034, 1.173, 0.285])
speedup_v2 = np.array([83.607, 25.802, 7.815, 2.452, 0.913, 0.319, 0.136])

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10,10), sharex=True)

# Laufzeiten plotten
ax1.plot(densities, bmm, marker='o', label='torch.bmm', color='tab:blue')
ax1.plot(densities, v1, marker='s', label='v1', color='tab:orange')
ax1.plot(densities, v2, marker='^', label='v2', color='tab:green')
ax1.set_ylabel('Laufzeit (ms)', fontsize=14)
ax1.set_title('Laufzeiten', fontsize=16)
ax1.legend()
ax1.grid(True, which="major", ls="--", lw=0.5)

# Speedup plotten
ax2.plot(densities, speedup_v1, marker='s', label='v1', color='tab:orange')
ax2.plot(densities, speedup_v2, marker='^', label='v2', color='tab:green')
ax2.axhline(1, color='grey', ls=':', lw=1)
ax2.set_xscale('log')
ax2.set_xlabel('Dichte', fontsize=14)
ax2.set_ylabel('Speedup', fontsize=14)
ax2.set_title('Durchschnitts-Speedup vs. torch.bmm', fontsize=16)
ax2.legend()
ax2.grid(True, which="major", ls="--", lw=0.5)

plt.tight_layout()
plt.savefig("aggregated_bmm_runtimes.png")