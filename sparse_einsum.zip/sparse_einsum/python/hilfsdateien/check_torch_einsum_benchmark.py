import os
import sys
import json
import time
import threading
import multiprocessing
from dataclasses import dataclass
from typing import List, Tuple, Any

# Setzen der Umgebungsvariable, falls das Datenverzeichnis existiert
data_dir = "/root/einsum_data"
if 'EINSUM_BENCHMARK_DATA_DIR' not in os.environ and os.path.exists(data_dir):
    os.environ['EINSUM_BENCHMARK_DATA_DIR'] = data_dir

try:
    import numpy as np
    import torch
    import opt_einsum as oe
    import einsum_benchmark
    from einsum_benchmark.meta import to_annotated_ssa_path, find_path
    import psutil # Notwendig für die Speicherüberwachung
except ImportError as e:
    print(f"Fehler: Eine benötigte Bibliothek ist nicht installiert. Bitte installieren Sie sie. ({e})", file=sys.stderr)
    sys.exit(1)

# ==============================================================================
# 1. DATENVORBEREITUNG (aus Ihrer Vorlage übernommen)
# ==============================================================================
@dataclass
class EinsumInstance:
    format_string: str
    ssa_path: List[Tuple[Any, ...]]
    tensors: List[np.ndarray]
    path: List[Tuple[Any, ...]]
    key: str

def get_predefined_instances(instance_keys: List[str], cache_file: str = "path_cache.json") -> List[EinsumInstance]:
    """
    Lädt vordefinierte Instanzen und verwendet einen lokalen Cache für die teure Pfadfindung.
    """
    if os.path.exists(cache_file):
        print(f"Lade Pfad-Cache aus '{cache_file}'...")
        with open(cache_file, 'r') as f:
            cached_paths = json.load(f)
    else:
        print(f"Kein Pfad-Cache gefunden. Er wird für die benötigten Instanzen neu erstellt.")
        cached_paths = {}

    prepared_instances: List[EinsumInstance] = []
    needs_saving = False

    print(f"Bereite {len(instance_keys)} Instanzen vor...")
    for key in instance_keys:
        path, ssa_path = None, None

        if key in cached_paths:
            path = cached_paths[key]['path']
        else:
            print(f"  [Compute] Pfad für '{key}' nicht im Cache. Berechne neu...")
            needs_saving = True
            try:
                instance_data = einsum_benchmark.instances[key]
                # Wir verwenden den von opt_einsum empfohlenen Pfad, falls verfügbar
                if instance_data.paths and instance_data.paths.opt_size:
                    path = instance_data.paths.opt_size.path
                else:
                    path = find_path(instance_data.format_string, *instance_data.tensors, minimize="size")[0]
                
                if path:
                    # ssa_path wird für diese Prüfung nicht benötigt, aber wir cachen ihn für Konsistenz
                    ssa_path = to_annotated_ssa_path(instance_data.format_string, path)
                    cached_paths[key] = {'path': path, 'ssa_path': ssa_path}
                else:
                    print(f"    -> Warnung: Konnte keinen Pfad für '{key}' finden. Wird übersprungen.")
                    continue
            except Exception as e:
                print(f"    -> Fehler bei der Pfadfindung für '{key}': {e}. Wird übersprungen.")
                continue
        
        try:
            instance_data = einsum_benchmark.instances[key]
            prepared_instances.append(EinsumInstance(
                format_string=instance_data.format_string,
                ssa_path=cached_paths.get(key, {}).get('ssa_path'), # Kann None sein
                tensors=instance_data.tensors,
                path=path,
                key=key,
            ))
        except Exception as e:
            print(f"    -> Fehler beim Laden der Instanzdaten für '{key}': {e}. Wird übersprungen.")
    
    if needs_saving:
        print(f"Speichere aktualisierten Pfad-Cache in '{cache_file}'...")
        with open(cache_file, 'w') as f:
            json.dump(cached_paths, f, indent=2)

    return prepared_instances

# ==============================================================================
# 2. PROZESS-FUNKTION FÜR DIE BERECHNUNG
# ==============================================================================
def einsum_computation_task(queue, format_string, tensors_torch, path):
    """
    Diese Funktion wird in einem separaten Prozess ausgeführt.
    Sie führt die Berechnung durch und legt das Ergebnis in eine Queue.
    """
    try:
        # Die eigentliche Berechnung
        result = oe.contract(format_string.replace(" ", ""), *tensors_torch, optimize=path, backend="torch")
        # Erfolg signalisieren (das Ergebnis selbst ist nicht wichtig)
        queue.put("success")
    except Exception as e:
        # Fehler signalisieren
        queue.put(e)

# ==============================================================================
# 3. SPEICHERÜBERWACHUNG
# ==============================================================================
def memory_monitor(process, memory_limit_gb, stop_event):
    """
    Überwacht den Speicherverbrauch des Zielprozesses in einem eigenen Thread.
    """
    p = psutil.Process(process.pid)
    while not stop_event.is_set():
        try:
            # RSS (Resident Set Size) ist eine gute Metrik für den realen Speicherverbrauch
            mem_info = p.memory_info()
            memory_gb = mem_info.rss / (1024 ** 3)
            if memory_gb > memory_limit_gb:
                print(f"\n    -> Speicherlimit überschritten ({memory_gb:.2f} GB > {memory_limit_gb:.2f} GB). Breche ab.", flush=True)
                process.terminate() # Prozess hart beenden
                return
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            # Prozess ist bereits beendet
            return
        time.sleep(0.2)

# ==============================================================================
# 4. HAUPTFUNKTION
# ==============================================================================
def main():
    torch.set_grad_enabled(False)

    # Dieselben Instanzen wie in Ihrer Vorlage
    PREDEFINED_INSTANCE_KEYS = [
        #"mc_2022_087", "mc_2022_079", 
        "mc_2021_036", 
        "wmc_2021_061", 
        #"mc_2022_025", 
        #"mc_2023_186", 
        # "wmc_2022_038", "mc_2023_188", 
        #"wmc_2023_036", 
        # "mc_2022_029", "mc_rw_blasted_case1_b14_even3", 
        #"mc_rw_log-1", 
        #"wmc_2021_145"
    ]
    
    # Konfiguration für die Prüfung
    TIMEOUT_SECONDS = 60
    
    # Speicherlimit: 90% des verfügbaren Gesamtspeichers
    total_memory_gb = psutil.virtual_memory().total / (1024 ** 3)
    MEMORY_LIMIT_GB = total_memory_gb * 0.90
    print(f"Systemspeicher: {total_memory_gb:.2f} GB. Setze Limit auf {MEMORY_LIMIT_GB:.2f} GB.")

    instances_to_check = get_predefined_instances(PREDEFINED_INSTANCE_KEYS)
    
    if not instances_to_check:
        print("\nKeine Instanzen konnten geladen werden. Programm wird beendet.")
        return

    successful_instances = []
    print(f"\nStarte Überprüfung für {len(instances_to_check)} Instanzen...")

    for i, instance in enumerate(instances_to_check):
        print(f"  [{i+1}/{len(instances_to_check)}] Prüfe Instanz: {instance.key}...", end="", flush=True)

        if not instance.path:
            print(" FEHLER (Kein Pfad gefunden)")
            continue

        # Konvertiere NumPy-Arrays zu PyTorch-Tensoren
        tensors_torch = [torch.from_numpy(t.astype(np.float64)) for t in instance.tensors]

        # Prozess-Setup
        ctx = multiprocessing.get_context('spawn') # 'spawn' ist sicherer mit CUDA
        queue = ctx.Queue()
        process = ctx.Process(target=einsum_computation_task, args=(queue, instance.format_string, tensors_torch, instance.path))
        
        # Speicherüberwachung-Setup
        stop_monitor_event = threading.Event()
        monitor_thread = threading.Thread(target=memory_monitor, args=(process, MEMORY_LIMIT_GB, stop_monitor_event))

        start_time = time.time()
        process.start()
        monitor_thread.start()

        process.join(timeout=TIMEOUT_SECONDS)
        
        # Monitor-Thread beenden
        stop_monitor_event.set()
        monitor_thread.join()

        if process.is_alive():
            # Timeout erreicht
            print(" TIMEOUT")
            process.terminate()
            process.join()
        elif process.exitcode == 0:
            # Erfolgreich beendet
            result = queue.get()
            if result == "success":
                duration = time.time() - start_time
                print(f" ERFOLG ({duration:.2f}s)")
                successful_instances.append(instance.key)
            else:
                # Fehler innerhalb der Berechnung
                print(f" FEHLER (Berechnung: {type(result).__name__})")
        else:
            # Abgebrochen (z.B. durch Speicherwächter) oder anderer Fehler
            print(" FEHLER (Prozess abgebrochen)")

    print("\n--- Ergebnis ---")
    print("Die folgenden Instanzen konnten erfolgreich mit `torch.einsum` berechnet werden:")
    print(successful_instances)
    print("----------------")


if __name__ == "__main__":
    # Stellt sicher, dass Multiprocessing in kompilierten Anwendungen (z.B. PyInstaller) funktioniert
    multiprocessing.freeze_support()
    main()