import os
import sys
import time
import contextlib
from typing import Dict, Any, List, Tuple

import numpy as np
import torch
import matplotlib.pyplot as plt

from wrapper import sparse_einsum_v1 as sparse_einsum  # type: ignore
from wrapper import sparse_einsum_v2 as sparse_einsum_v2  # type: ignore

def set_reproducible(seed: int = 42):
    np.random.seed(seed)
    torch.manual_seed(seed)

def np_to_torch_sparse(np_array: np.ndarray) -> torch.Tensor:
    """
    Konvertiert ein NumPy-Array in einen PyTorch sparse_coo_tensor.
    """
    non_zero_indices = np.nonzero(np_array)
    if len(non_zero_indices[0]) == 0:
        indices_tensor = torch.empty((np_array.ndim, 0), dtype=torch.long)
        values_tensor = torch.empty((0,), dtype=torch.float32)
    else:
        indices_tensor = torch.tensor(np.array(non_zero_indices), dtype=torch.long)
        values_tensor = torch.tensor(np_array[non_zero_indices], dtype=torch.float32)
    sparse_tensor = torch.sparse_coo_tensor(
        indices=indices_tensor,
        values=values_tensor,
        size=np_array.shape,
        dtype=torch.float32,
    )
    return sparse_tensor.coalesce()


def make_random_sparse_batch(B: int, J: int, I: int, K: int, density: float) -> Tuple[np.ndarray, np.ndarray]:
    """
    Erzeuge zwei dichte NumPy-Arrays in Layouts:
      A_np: (B, J, I)
      B_np: (B, J, K)
    mit gegebener Dichte (Anteil Nicht-Null-Elemente).
    Werte sind float32.
    """
    assert 0.0 <= density <= 1.0
    A_np = (np.random.rand(B, J, I).astype(np.float32))
    B_np = (np.random.rand(B, J, K).astype(np.float32))

    # Binäre Maske mit Wahrscheinlichkeit 'density' für 1
    if density < 1.0:
        A_mask = (np.random.rand(B, J, I) < density)
        B_mask = (np.random.rand(B, J, K) < density)
        A_np *= A_mask.astype(np.float32)
        B_np *= B_mask.astype(np.float32)

    return A_np, B_np


def to_torch_dense_for_bmm(A_np: np.ndarray, B_np: np.ndarray) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Wandle die (B, J, I) / (B, J, K) Layouts in dichte Torch-Tensoren für torch.bmm um:
      A_dense_bmm: (B, I, J) = A_np.transpose(1, 2)
      B_dense_bmm: (B, J, K) = B_np
    """
    A_dense_bmm = torch.from_numpy(A_np).transpose(1, 2).contiguous()  # (B, I, J)
    B_dense_bmm = torch.from_numpy(B_np).contiguous()                  # (B, J, K)
    return A_dense_bmm, B_dense_bmm


def time_torch_bmm_runs(A_dense_bmm: torch.Tensor, B_dense_bmm: torch.Tensor, num_runs: int = 10) -> List[float]:
    """
    Liefert Einzelzeiten je Run (keinen Mittelwert), um später Speedups über alle 100 Berechnungen zu mitteln.
    """
    times: List[float] = []
    torch.set_num_threads(max(1, torch.get_num_threads()))
    with torch.no_grad():
        # Warmup
        for _ in range(2):
            _ = torch.bmm(A_dense_bmm, B_dense_bmm)

        for _ in range(num_runs):
            t0 = time.perf_counter()
            _ = torch.bmm(A_dense_bmm, B_dense_bmm)
            t1 = time.perf_counter()
            times.append(t1 - t0)
    return times


def time_my_sparse_einsum_runs(
    ssa_path: List[Tuple[int, int, str]],
    A_sparse: torch.Tensor,
    B_sparse: torch.Tensor,
    num_runs: int = 10,
) -> Tuple[List[float], List[List[Tuple[str, float]]]]:
    """
    Liefert:
      - Einzelzeiten je Run (für Speedups)
      - UND die pro-Run-Schritt-Timings als Liste von Listen [(step_name, step_time), ...] pro Run.
    """
    times: List[float] = []
    step_timings_runs: List[List[Tuple[str, float]]] = []
    # Warmup

    for _ in range(2):
        _ = sparse_einsum(ssa_path, A_sparse, B_sparse)

    result = []
    for _ in range(num_runs):
        t0 = time.perf_counter()
        result, timings = sparse_einsum(ssa_path, A_sparse, B_sparse)
        t1 = time.perf_counter()
        times.append(t1 - t0)
        step_timings_runs.append(timings)
    return times, step_timings_runs


def time_my_sparse_einsum_v2_runs(
    ssa_path: List[Tuple[int, int, str]],
    A_sparse: torch.Tensor,
    B_sparse: torch.Tensor,
    num_runs: int = 10,
) -> Tuple[List[float], List[List[Tuple[str, float]]]]:
    """
    Zeitmessung für sparse_einsum_v2, analog zu time_my_sparse_einsum_runs.
    """
    times: List[float] = []
    step_timings_runs: List[List[Tuple[str, float]]] = []
    # Warmup
    for _ in range(2):
        _ = sparse_einsum_v2(ssa_path, A_sparse, B_sparse)
    result = []
    for _ in range(num_runs):
        t0 = time.perf_counter()
        result,timings = sparse_einsum_v2(ssa_path, A_sparse, B_sparse)
        t1 = time.perf_counter()
        times.append(t1 - t0)
        step_timings_runs.append(timings)
    return times, step_timings_runs


def density_schedule(cap: float = 0.0064) -> List[float]:
    """
    Erzeuge eine Liste von Dichten, beginnend bei '0.0001' und pro Schritt verdoppelt.
    Gekappt bei 'cap'.
    """
    ds = []
    d = 0.0001
    while d <= cap:
        ds.append(min(d, cap))
        d *= 2.0
    return ds

def _avg_step_timings(step_runs: List[List[Tuple[str, float]]]) -> List[Tuple[str, float]]:
    """
    Mittelt Schritt-Timings über alle Runs.
    Erwartet eine Liste von Runs; jeder Run ist eine Liste von (name, time).
    """
    if not step_runs:
        return []
    # Versuche, positionsbasiert zu mitteln (schnell), falle auf name-basiert zurück, falls Uneinheitlichkeit.
    first = step_runs[0]
    try:
        out: List[Tuple[str, float]] = []
        for i, (name, _) in enumerate(first):
            vals = [run[i][1] for run in step_runs]
            out.append((name, float(np.mean(vals))))
        # Validierung der Namen über Positionen
        for run in step_runs:
            assert [n for n, _ in run] == [n for n, _ in first]
        return out
    except Exception:
        # Name-basierte Mittelung (robust)
        buckets: Dict[str, List[float]] = {}
        order = [n for n, _ in first]
        for run in step_runs:
            for n, t in run:
                buckets.setdefault(n, []).append(t)
                if n not in order:
                    order.append(n)
        return [(n, float(np.mean(buckets.get(n, [])))) for n in order]


def benchmark_density_sweep(
    B: int = 32, J: int = 128, I: int = 128, K: int = 128,
    start_density: float = 0.00005,
    density_steps: int = 8,
    num_instances_per_density: int = 10,
    runs_per_instance: int = 10,
) -> Tuple[
    List[Dict[str, Any]],
    List[float],
    List[float],
    List[float],
    List[float],
]:
    """
    Für jede Dichte:
      - 10 Instanzen erzeugen (A_np, B_np)
      - jede Instanz 10x berechnen
      - Messwerte notieren und am Ende Durchschnitt berechnen
      - Printen der Messwerte

    Rückgabe:
      - results: Liste mit Kennzahlen pro verarbeiteter Dichte
      - densities_done: tatsächlich verarbeitete Dichten
      - avg_bmm_per_density: mittlere bmm-Zeit pro Dichte
      - avg_my_per_density_v1: mittlere sparse_einsum-Zeit pro Dichte
      - avg_my_per_density_v2: mittlere sparse_einsum_v2-Zeit pro Dichte
    """
    einsum_expr = "bij,bjk->bik"
    ssa_path: List[Tuple[int, int, str]] = [(0, 1, einsum_expr)]
    results: List[Dict[str, Any]] = []

    densities = density_schedule(start=start_density, steps=density_steps)
    print(f"Benchmark: B={B}, J={J}, I={I}, K={K}")
    print(f"Dichten: {densities}")
    print("Hinweis: Pro Dichte 10 Instanzen x 10 Runs = 100 Speedups (Mittelwert berichtet)\n")

    densities_done: List[float] = []
    avg_bmm_per_density: List[float] = []
    avg_my_per_density_v1: List[float] = []
    avg_my_per_density_v2: List[float] = []

    for d_idx, density in enumerate(densities):
        all_speedups_v1: List[float] = []
        all_speedups_v2: List[float] = []
        all_bmm_times: List[float] = []
        all_my_times_v1: List[float] = []
        all_my_times_v2: List[float] = []

        # Schritt-Timings (v1) über alle Runs dieser Dichte
        all_step_timings_v1_runs: List[List[Tuple[str, float]]] = []
        all_step_timings_v2_runs: List[List[Tuple[str, float]]] = []

        for inst in range(num_instances_per_density):
            # Arrays erzeugen
            A_np, B_np = make_random_sparse_batch(B, J, I, K, density=density)

            # Tensors für beide Pfade bauen (Konvertierung nicht in die Laufzeitmessung einbeziehen)
            A_sparse = np_to_torch_sparse(A_np)
            B_sparse = np_to_torch_sparse(B_np)
            A_dense_bmm, B_dense_bmm = to_torch_dense_for_bmm(A_np, B_np)
            print("start torch")
            # Einzelzeiten erfassen
            bmm_times = time_torch_bmm_runs(A_dense_bmm, B_dense_bmm, num_runs=runs_per_instance)
            print("\neinsum_v1\n")
            my_times_v1, step_timings_v1_runs = time_my_sparse_einsum_runs(ssa_path, A_sparse, B_sparse, num_runs=runs_per_instance)
            print("\neinsum_v2\n")
            my_times_v2, step_timings_v2_runs = time_my_sparse_einsum_v2_runs(ssa_path, A_sparse, B_sparse, num_runs=runs_per_instance)

            # Konsistenz: gleiche Anzahl Runs
            assert len(bmm_times) == len(my_times_v1) == len(my_times_v2) == runs_per_instance

            # Schritt-Timings sammeln
            all_step_timings_v1_runs.extend(step_timings_v1_runs)
            all_step_timings_v2_runs.extend(step_timings_v2_runs)

            # Messwerte pro Run sammeln
            for r in range(runs_per_instance):
                tb = bmm_times[r]
                tm1 = my_times_v1[r]
                tm2 = my_times_v2[r]

                all_speedups_v1.append((tb / tm1) if tm1 > 0 else float("inf"))
                all_speedups_v2.append((tb / tm2) if tm2 > 0 else float("inf"))
                all_bmm_times.append(tb)
                all_my_times_v1.append(tm1)
                all_my_times_v2.append(tm2)

        # Aggregation über 100 Runs (10 Instanzen x 10 Runs)
        avg_speedup_v1 = float(np.mean(all_speedups_v1)) if len(all_speedups_v1) > 0 else float("nan")
        std_speedup_v1 = float(np.std(all_speedups_v1)) if len(all_speedups_v1) > 0 else float("nan")
        avg_speedup_v2 = float(np.mean(all_speedups_v2)) if len(all_speedups_v2) > 0 else float("nan")
        std_speedup_v2 = float(np.std(all_speedups_v2)) if len(all_speedups_v2) > 0 else float("nan")

        avg_bmm = float(np.mean(all_bmm_times)) if len(all_bmm_times) > 0 else float("nan")
        avg_my_v1 = float(np.mean(all_my_times_v1)) if len(all_my_times_v1) > 0 else float("nan")
        avg_my_v2 = float(np.mean(all_my_times_v2)) if len(all_my_times_v2) > 0 else float("nan")
        ratio_of_avgs_v1 = (avg_bmm / avg_my_v1) if (avg_my_v1 > 0) else float("inf")
        ratio_of_avgs_v2 = (avg_bmm / avg_my_v2) if (avg_my_v2 > 0) else float("inf")

        # Durchschnittliche Schritt-Timings (v1) über alle 100 Runs
        avg_steps_v1 = _avg_step_timings(all_step_timings_v1_runs)
        avg_steps_v2 = _avg_step_timings(all_step_timings_v2_runs)
        # Schön formatieren: auf 6 Dezimalstellen runden
        avg_steps_v1_printable = [(name, round(val, 6)) for name, val in avg_steps_v1]
        avg_steps_v2_printable = [(name, round(val, 6)) for name, val in avg_steps_v2]
        print(avg_steps_v1_printable)
        print(avg_steps_v2_printable)

        result_row = dict(
            density=float(density),
            # v1
            avg_speedup_over_100_v1=avg_speedup_v1,  # Mittel der 100 Einzel-Speedups
            std_speedup_over_100_v1=std_speedup_v1,
            avg_my_time_s_v1=avg_my_v1,
            ratio_of_average_times_v1=ratio_of_avgs_v1,
            # v2
            avg_speedup_over_100_v2=avg_speedup_v2,
            std_speedup_over_100_v2=std_speedup_v2,
            avg_my_time_s_v2=avg_my_v2,
            ratio_of_average_times_v2=ratio_of_avgs_v2,
            # bmm
            avg_bmm_time_s=avg_bmm,
            runs=len(all_speedups_v1),
        )
        results.append(result_row)

        
        densities_done.append(density)
        avg_bmm_per_density.append(avg_bmm)
        avg_my_per_density_v1.append(avg_my_v1)
        avg_my_per_density_v2.append(avg_my_v2)

        print(
            f"[Density {density:.8f}] "
            f"Avg Speedup v1 (mean of 100 ratios): {avg_speedup_v1:.3f} (± {std_speedup_v1:.3f}) | "
            f"Avg Speedup v2 (mean of 100 ratios): {avg_speedup_v2:.3f} (± {std_speedup_v2:.3f}) | "
            f"Avg times: bmm={avg_bmm*1e3:.3f} ms, v1={avg_my_v1*1e3:.3f} ms, v2={avg_my_v2*1e3:.3f} ms | "
            f"Ratio(avg times): v1={ratio_of_avgs_v1:.3f}, v2={ratio_of_avgs_v2:.3f}"
        )

    print("\nFertig.")
    return results, densities_done, avg_bmm_per_density, avg_my_per_density_v1, avg_my_per_density_v2


def main():
    # Reproduzierbarkeit
    set_reproducible(123)

    # Für fairen CPU-Vergleich
    torch.set_grad_enabled(False)

    # Problemgröße
    B, J, I, K = 512, 512, 512, 512

    # Konfiguration:
    start_density = 0.0001            # Start bei 0.0001
    density_steps = 12                 # pro Schritt verdoppeln (anpassbar)
    num_instances = 10                 # pro Dichte 10 Instanzen
    runs_per_instance = 10             # jede Instanz 10x berechnen

    # Benchmark starten
    results, densities_done, avg_bmm_per_density, avg_my_per_density_v1, avg_my_per_density_v2 = benchmark_density_sweep(
        B=B, J=J, I=I, K=K,
        start_density=start_density,
        density_steps=density_steps,
        num_instances_per_density=num_instances,
        runs_per_instance=runs_per_instance,
    )


if __name__ == "__main__":
    main()