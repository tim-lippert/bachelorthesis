import time
from typing import Dict, List, Tuple, NamedTuple

import numpy as np
import torch
import random
from  einsum_benchmark.generators.random import connected_hypernetwork
from einsum_benchmark.meta import find_path, to_annotated_ssa_path



# Importiere die Wrapper
from wrapper import sparse_einsum_v1 as sparse_einsum_v1  # type: ignore
from wrapper import sparse_einsum_v2 as sparse_einsum_v2  # type: ignore


# ==============================================================================
# Generators
# ==============================================================================

class EinsumExpression(NamedTuple):
    """Kapselt einen Einsum-Ausdruck und die zugehörigen Tensor-Shapes."""
    expression: str
    shapes: List[Tuple[int, ...]]
    tensors: List[np.ndarray]
    path: List[Tuple[int,int]]
    annotated_ssa_path: List[Tuple[int,int,str]]
    density: float

def generate_einsum_expressions(seed = 42, count = 10, densities=[0.0001]):
    random.seed(seed)
    einsum_expressions = []
    for d in densities:
        for i in range(count):
            print("begin")
            format_string, shapes = connected_hypernetwork(
                number_of_tensors=10,
                regularity=2,
                max_tensor_order=3,
                max_edge_order=2,
                diagonals_in_hyper_edges=False,
                number_of_output_indices=random.randint(1,2),
                max_output_index_order=1,
                diagonals_in_output_indices=False,
                number_of_self_edges=0,
                number_of_single_summation_indices=random.randint(0,2),
                min_axis_size=8,
                max_axis_size=64,
                seed=i,
                global_dim=False
            )
            print("end")
            tensors = make_random_sparse_tensors(shapes, d)
            path = find_path(format_string, *tensors, minimize="size",)[0]
            annotated_ssa_path = to_annotated_ssa_path(format_string, path)
            einsum_expressions.append(EinsumExpression(format_string, shapes, tensors, path, annotated_ssa_path, d))
    return einsum_expressions


def make_random_sparse_tensors(
    shapes: List[Tuple[int, ...]], density: float
) -> List[np.ndarray]:
    sparse_tensor_list = []
    for shape in shapes:
        tensor = (np.random.rand(*shape).astype(np.float32))
        if density < 1.0:
            tensor *= (np.random.rand(*shape) < density)
        sparse_tensor_list.append(tensor)
    return sparse_tensor_list


# ==============================================================================
# Helpers
# ==============================================================================

def set_reproducible(seed: int = 42):
    np.random.seed(seed)
    torch.manual_seed(seed)

def np_to_torch_sparse(np_array: np.ndarray) -> torch.Tensor:
    non_zero_indices = np.nonzero(np_array)
    if len(non_zero_indices[0]) == 0:
        indices = torch.empty((np_array.ndim, 0), dtype=torch.long)
        values = torch.empty((0,), dtype=torch.float32)
    else:
        indices = torch.tensor(np.array(non_zero_indices), dtype=torch.long)
        values = torch.tensor(np_array[non_zero_indices], dtype=torch.float32)
    return torch.sparse_coo_tensor(indices, values, np_array.shape).coalesce()

def density_schedule(start: float, steps: int, cap: float = 1.0) -> List[float]:
    ds = []
    d = start
    for _ in range(steps):
        ds.append(min(d, cap))
        if d >= cap: break
        d *= 2.0
    return ds


# ==============================================================================
# Timing Functions
# ==============================================================================

def time_torch_einsum_runs(expression: str, A_dense: torch.Tensor, B_dense: torch.Tensor, num_runs: int) -> List[float]:
    times = []
    result = []
    with torch.no_grad():
        for _ in range(2): torch.einsum(expression, A_dense, B_dense)
        for _ in range(num_runs):
            t0 = time.perf_counter(); result = torch.einsum(expression, A_dense, B_dense); t1 = time.perf_counter()
            times.append(t1 - t0)
    print("Torch sum: ", torch.sum(result))
    return times

def time_my_sparse_einsum_runs(ssa_path: List[Tuple[int, int, str]], A_sparse: torch.Tensor, B_sparse: torch.Tensor, num_runs: int) -> List[float]:
    times = []
    result = []
    for _ in range(2): sparse_einsum_v1(ssa_path, A_sparse, B_sparse)
    for _ in range(num_runs):
        t0 = time.perf_counter(); 
        result = sparse_einsum_v1(ssa_path, A_sparse, B_sparse); 
        t1 = time.perf_counter()
        times.append(t1 - t0)
    print("v1 sum: ", torch.sum(result[0]))
    return times

def time_my_sparse_einsum_v2_runs(ssa_path: List[Tuple[int, int, str]], A_sparse: torch.Tensor, B_sparse: torch.Tensor, num_runs: int) -> List[float]:
    times = []
    result = []
    for _ in range(2): sparse_einsum_v2(ssa_path, A_sparse, B_sparse)
    for _ in range(num_runs):
        t0 = time.perf_counter(); 
        result = sparse_einsum_v2(ssa_path, A_sparse, B_sparse); 
        t1 = time.perf_counter()
        times.append(t1 - t0)
    print("v2 sum: ", torch.sum(result[0]))
    return times


# ==============================================================================
# Benchmarking
# ==============================================================================

def run_aggregated_benchmark(
    expressions: List[EinsumExpression],
    densities: List[float],
    runs_per_expression: int = 3,
) -> Dict[str, List[float]]:
    """
    Führt den Benchmark über alle Ausdrücke und Dichten durch und aggregiert die Ergebnisse.
    Zusätzlich: Speedup wird pro Expression berechnet (speedup_i = torch_i / my_i) und
    danach über alle Expressions gemittelt.
    """
    densities_done: List[float] = []
    avg_torch_per_density: List[float] = []
    avg_my_v1_per_density: List[float] = []
    avg_my_v2_per_density: List[float] = []

    avg_my_v1_speedup_per_density: List[float] = []
    avg_my_v2_speedup_per_density: List[float] = []

    num_expr = len(expressions)
    print(f"Starte aggregierten Benchmark für {num_expr} Einsum-Ausdrücke.")
    print(f"Dichten: {[f'{d:.1e}' for d in densities]}")
    
    density_to_exprs = {}
    for expr in expressions:
        density_to_exprs.setdefault(expr.density, []).append(expr)

    for density in densities:

        all_torch_times: List[float] = []
        all_my_times_v1: List[float] = []
        all_my_times_v2: List[float] = []

        v1_speedups_expr: List[float] = []
        v2_speedups_expr: List[float] = []

        exprs = density_to_exprs.get(density, [])
        if len(exprs) == 0:
            print(f"Keine Expressions für Dichte {density:.1e} vorhanden!")
            continue


        for i, expr in enumerate(exprs):
            print(f"\r  Density {density:.1e}: Processing expression {i+1}/{num_expr}...", end="")

            ssa_path = expr.annotated_ssa_path

            torch_dense_tensors = [torch.from_numpy(i) for i in expr.tensors]
            torch_sparse_tensors = [np_to_torch_sparse(i) for i in expr.tensors]

            # torch.einsum Zeit
            torch_time = float(np.mean(time_torch_einsum_runs(expr.expression, torch_dense_tensors, runs_per_expression)))
            all_torch_times.append(torch_time)

            # v1
            my_time_v1 = float(np.mean(time_my_sparse_einsum_runs(ssa_path, torch_sparse_tensors, runs_per_expression)))
            all_my_times_v1.append(my_time_v1)
            if my_time_v1 > 0 and np.isfinite(my_time_v1) and np.isfinite(torch_time):
                v1_speedups_expr.append(torch_time / my_time_v1)

            # v2
            my_time_v2 = float(np.mean(time_my_sparse_einsum_v2_runs(ssa_path, torch_sparse_tensors, runs_per_expression)))
            all_my_times_v2.append(my_time_v2)
            if my_time_v2 > 0 and np.isfinite(my_time_v2) and np.isfinite(torch_time):
                v2_speedups_expr.append(torch_time / my_time_v2)

        print()

        # Mittelwerte der Zeiten
        avg_torch = float(np.mean(all_torch_times)) if all_torch_times else np.nan
        avg_v1 = float(np.mean(all_my_times_v1))
        avg_v2 = float(np.mean(all_my_times_v2))

        # Mittel der per-Expression-Speedups
        v1_speedup_avg = float(np.mean(v1_speedups_expr)) if v1_speedups_expr else np.nan
        v2_speedup_avg = float(np.mean(v2_speedups_expr)) if v2_speedups_expr else np.nan

        # Sammeln
        densities_done.append(density)
        avg_torch_per_density.append(avg_torch)
        avg_my_v1_per_density.append(avg_v1)
        avg_my_v2_per_density.append(avg_v2)
        avg_my_v1_speedup_per_density.append(v1_speedup_avg)
        avg_my_v2_speedup_per_density.append(v2_speedup_avg)

        # Log-Ausgabe inkl. Speedups (per-Expression gemittelt)
        log_msg = f"  -> Avg Times (ms): torch={avg_torch*1e3:.3f}"
        #v1
        log_msg += f", v1={avg_v1*1e3:.3f}"
        if np.isfinite(v1_speedup_avg):
            log_msg += f" | Speedup v1=x{v1_speedup_avg:.2f}"
        #v2
        log_msg += f", v2={avg_v2*1e3:.3f}"
        if np.isfinite(v2_speedup_avg):
            log_msg += f" | Speedup v2=x{v2_speedup_avg:.2f}"
        print(log_msg)


    return {
        "densities": densities_done,
        "avg_torch_times": avg_torch_per_density,
        "avg_my_times_v1": avg_my_v1_per_density,
        "avg_my_times_v2": avg_my_v2_per_density,
        "avg_my_v1_speedup_per_density": avg_my_v1_speedup_per_density,
        "avg_my_v2_speedup_per_density": avg_my_v2_speedup_per_density,
    }


# ==============================================================================
# Main Execution
# ==============================================================================

def main():
    set_reproducible(123)
    torch.set_grad_enabled(False)

    # Konfiguration
    num_expressions_to_gen = 10
    runs_per_expression = 3
    start_density = 0.0001
    density_steps = 10
    densities = density_schedule(start=start_density, steps=density_steps, cap = 0.0128)
    expressions = generate_einsum_expressions(seed=42, count=num_expressions_to_gen, densities=densities)
    

    results = run_aggregated_benchmark(
        expressions=expressions,
        densities=densities,
        runs_per_expression=runs_per_expression,
    )

    print("\nBenchmark abgeschlossen.")


if __name__ == "__main__":
    main()